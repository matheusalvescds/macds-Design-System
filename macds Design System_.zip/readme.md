# macds — Design System

Sistema de design e movimento pessoal de **Matheus Alves Cruz da Silva** (`macds`, sempre em caixa baixa — as iniciais que ele já usa em e-mail, LinkedIn e repositórios).

**Artefato principal:** site-currículo de página única, responsivo, que funciona ao mesmo tempo como currículo online e como prova de capacidade técnica. **Extensão secundária:** peças de conteúdo para LinkedIn (carrossel 1080×1350, post 1080×1080, banner de perfil 1584×396).

**Conceito:** cáustica — o desenho que a luz forma ao atravessar vidro ou água. A identidade não vem da cor; vem do comportamento da luz sobre superfícies escuras. Estritamente monocromática. A diferenciação está no movimento.

## Fontes deste sistema

Materiais recebidos do autor (ver `uploads/` no projeto original):

- `luz-e-estrutura.png` — a silhueta do autor desenhada só por fios de luz sobre preto; é o plate-retrato da marca. (Substituiu a referência original de mesmo nome a pedido dele.)
- `macds_ref_02_vidro-refracao.png` — forma de vidro fechada, refração e especulares.
- `macds_ref_03_formas-liquidas.png` — formas líquidas cromadas, alto contraste.
- `macds_ref_04_curvas-metalicas.png` — curvas metálicas, gradientes de luminância.
  Todas copiadas para `assets/imagery/` (uso como plate de fundo, sempre em grayscale).
- Três capturas do Behance em PDF (landing page de agência 2025, OCTO SMM Agency, KONTOUR Studios) — referência de layout editorial e ritmo de seções. **Não foram usadas como fonte de marca**; nenhuma identidade de terceiros foi copiada.
- Três arquivos `.txt` com o CSS do próprio site do Behance (variáveis `--be-*`). São artefato da captura, não material de marca — ignorados de propósito.

Não havia código-fonte, arquivo Figma ou binários de fonte. **Não existe arquivo de logotipo**: o wordmark é tipografia — "macds" em Space Grotesk com tracking bem negativo — e é assim que ele deve ser renderizado sempre (`components/core/Wordmark.jsx`). Nada foi desenhado ou inventado como marca.

## Índice

| Arquivo | O que é |
| --- | --- |
| `styles.css` | ponto de entrada; só `@import` |
| `tokens/colors.css` | rampa monocromática + aliases semânticos |
| `tokens/typography.css` | famílias, escala fluida, tracking, leading |
| `tokens/spacing.css` | escala 4px, ritmo de seção, breakpoints |
| `tokens/borders.css` | hairlines e raios |
| `tokens/effects.css` | grão, aresta de luz, halo, vidro, cáustica, zona de silêncio |
| `tokens/motion.css` | easing, durações, keyframes dos presets |
| `tokens/base.css` | reset, canvas, papéis de texto, foco, grão |
| `tokens/theme-light.css` | tema claro: `[data-theme="light"]`, onde o preto puro passa a ser a luz |
| `tokens/fonts.css` | webfonts (Google Fonts — ver Substituições) |
| `guidelines/*.card.html` | 20 cards de fundamento (Colors, Type, Spacing, Brand, Motion) |
| `components/` | primitivos React (lista abaixo) |
| `ui_kits/site/` | site-currículo completo, interativo |
| `ui_kits/linkedin/` | carrossel, post e banner em pixel real |
| `assets/imagery/` | os quatro plates de referência |
| `assets/textures/grain-256.png` | textura de ruído do overlay obrigatório |
| `SKILL.md` | invólucro para uso como Agent Skill |

### Componentes

`components/core/`: **Button**, **IconButton**, **Wordmark**, **Icon**, **Tag**, **Eyebrow**, **Divider**, **ThemeToggle**
`components/motion/`: **SweepText**, **CausticBackdrop**, **RefractionSurface**, **Magnetic**, **ScrollMask** (+ `useScrollProgress`), **Parallax**, **Shatter**, **Marquee**, **ScrollProgress**
`components/surfaces/`: **Grain**, **GlassPanel**, **ProjectCard**
`components/content/`: **SectionHeader**, **TimelineItem**, **StackGroup**, **CredentialItem**, **SocialLink**
`components/forms/`: **Input** (com variante `textarea`)

Cada diretório tem um card `@dsCard`; cada componente tem `.d.ts` (contrato de props) e `.prompt.md` (quando e como usar).

**Adições intencionais:** o briefing descreve marca, movimento e regras, não um inventário de componentes. O conjunto acima foi derivado das seções exigidas do site (hero, sobre, stack, projetos, timeline, formação, contato) e dos presets de movimento. `Icon` existe porque nenhum set de ícones foi fornecido e o sistema precisa de um único caminho para glifos.

## CONTENT FUNDAMENTALS

- **Idioma:** português do Brasil. Termos técnicos ficam em inglês quando é assim que se fala (`front-end`, `design system`, `lazy-load`, `commit`).
- **Caixa:** caixa baixa em quase tudo — wordmark, títulos de seção, títulos de projeto, labels de botão. Caixa alta só no eyebrow em mono (`02 — STACK E COMPETÊNCIAS`). Nomes próprios e siglas mantêm a forma correta (WCAG, GSAP, React).
- **Pessoa:** primeira pessoa do singular, sem se apresentar em terceira pessoa. "Construo interfaces que precisam aguentar produção." O recrutador é tratado por "você", direto, sem formalidade de carta.
- **Tom:** matter-of-fact e verificável. Números concretos em vez de adjetivos: "LCP médio de 4,3s para 1,8s em seis meses", não "performance excepcional". Nenhuma menção a paixão, jornada ou sinergia.
- **Frases:** curtas, com verbo na frente. Títulos sem ponto final. Parágrafos de duas a três frases; nada de bloco longo.
- **Labels de ação:** verbo + objeto em caixa baixa — "ver projetos", "baixar CV", "enviar mensagem", "ver projeto".
- **Períodos:** travessão e "agora" para o presente: `2023 — agora`.
- **Erros e estados:** enunciados em texto simples, sem cor e sem alarme — "endereço incompleto", "respondo em até dois dias úteis".
- **Emoji:** nunca. Nem em peças de LinkedIn.
- **Exclamação:** nunca. Ironia e superlativos, também não.
- **Peças de LinkedIn:** mesma voz, corpo mínimo de 28px em arte de 1080; a chamada é um pedido concreto ("Comente 'perf' e eu te mando"), não um call-to-action genérico.

## VISUAL FOUNDATIONS

**Cor.** Monocromático sem exceção. Canvas `#050506`; superfícies `#0E0E10` e `#1A1A1D`; borda `#2A2A2E`; texto secundário `#8E8E93`; texto primário `#F2F2F4`. Branco puro `#FFFFFF` **não é cor de texto** — é luz: aresta iluminada, halo, fio de luz, especular. Não existe hue de acento, nem cor semântica: erro, sucesso e destaque são passos de luminância. Cinza médio como fundo é proibido.

**Grão.** Overlay de ruído a 4% (`assets/textures/grain-256.png`, `mix-blend-mode: screen`) em toda página e toda peça exportada. Sem ele o preto fica morto e os gradientes racham na compressão.

**Tipografia.** Display: Space Grotesk 500–700, tracking de −0.035em a −0.055em. Corpo: Inter 400–500, leading 1.6, medida máxima 64ch. Código e metadados: JetBrains Mono. Hierarquia agressiva — hero em `clamp(3.5rem, 11vw, 10.5rem)` contra corpo de 17px, com muito vazio entre eles. Escala substitui cor como sinal de importância.

**Espaço.** Base 4px. `--section-y: clamp(96px,14vh,200px)` entre seções, `--gutter: clamp(20px,5vw,64px)` nas laterais, container 1280px. O vazio é estrutural, não sobra.

**Fundos.** Preto sólido é o padrão. Imagem entra como *plate* de luminância: os quatro references em grayscale, `mix-blend-mode: screen` ou opacidade baixa, sempre com uma zona de silêncio sob o texto (`--silence-veil`, `.macds-silence`, ou `GlassPanel strong`). Cáustica animada apenas no fundo do hero. Nenhum gradiente colorido, nenhum padrão repetido, nenhuma ilustração.

**Bordas e raios.** Hairline de 1px em `--border`; hairlines de seção desvanecem nas pontas (`--hairline-fade`). Raios pequenos e estruturais: 2 / 4 / 8 / 14 / 22px. `--radius-full` é reservado para nós de luz e formas de lente, nunca para botões.

**Cards.** Superfície `#0E0E10`, hairline, `inset 0 1px 0 rgba(255,255,255,.10)` no topo (aresta iluminada) e, quando precisa de profundidade, `--depth-drop` (sombra preta, quase invisível, sem blur cinza). **Sombra difusa genérica não existe neste sistema.** Card de projeto = plate de imagem em cima, texto em superfície sólida embaixo — texto nunca sobre a imagem.

**Transparência e blur.** Só onde a metáfora de vidro se aplica: nav ao rolar, `GlassPanel`, veils de proteção. Sempre `saturate(0)` junto do blur — vidro monocromático.

**Hover.** A luz sobe, o elemento não. Botão ghost: borda vai de `--border-strong` para `--border-lit` e a aresta superior intensifica. Botão light: halo de `--halo-sm` para `--halo-md`. Link: sublinhado aparece com offset 0.28em, sem mudar de cor. Card de projeto: refração (`feDisplacementMap`) mais especular seguindo o cursor. Linha de contato: desloca 12px para a direita e acende a régua. **Nunca scale, nunca cor.**

**Press.** `opacity: .72`. Sem encolher, sem mudar de fundo.

**Foco.** `outline: 1px solid rgba(255,255,255,.70)` com `outline-offset: 3px`, visível em todo controle, navegação completa por teclado.

**Movimento ligado ao scroll.** Cinco presets ligados à rolagem, todos com um único listener rAF-throttled: `ScrollMask` (light sweep escrito pela rolagem), `Parallax` (profundidade por velocidade diferencial), `Fragment` (fragmentação na saída, em estilhaços verticais), `Marquee` (ticker infinito) e `ScrollProgress` (filamento de 1px com a posição de leitura). Somam-se à fonte de luz atrelada ao scroll do próprio app.

**Tema claro.** `tokens/theme-light.css` não clareia o tema escuro: inverte a regra. Em papel `#F2F2F4`, a "luz" passa a ser tinta preta pura — arestas, fios e halos viram sombra; o grão troca `screen` por `multiply`; plates com `class="macds-plate"` são invertidos para continuarem legíveis. Alternância via `ThemeToggle` (persistida em localStorage).

**Movimento.** Easing padrão `cubic-bezier(0.22, 1, 0.36, 1)`; durações 400 / 550 / 700ms; ambiente 14s. Presets: light sweep reveal, refração no hover, cáustica animada, fonte de luz atrelada ao scroll, fragmentação na saída, stagger por caractere (26ms), cursor magnético, morph de path SVG. Proibidos: fade-in, slide-up, bounce, scale no hover, animação em elemento já visível, pré-loader, scroll sequestrado.

**Imagens.** Sempre preto e branco de alto contraste, luz sobre preto, com grão. Nada de cor, nada de warm/cool — só luminância.

**Layout fixo.** Nav fixa e transparente até 40px de scroll; uma única camada de luz fixa atrás do conteúdo (`ScrollLight`); grão fixo no topo de tudo (`z-index: 9999`).

**Responsividade.** Mobile-first; breakpoints 640 / 768 / 1024 / 1280. Abaixo de 768px refração e cáustica congelam — o estado estático é o fallback desenhado, não uma degradação.

**Acessibilidade e performance.** `prefers-reduced-motion` respeitado em todos os presets com fallback estático real; contraste mínimo 4.5:1 medido contra a superfície real; alvo mínimo 44px; HTML semântico para Ctrl+F funcionar. Animação só em `transform` e `opacity`; imagens em lazy-load; nenhum pré-loader; WebGL/shader só depois do first paint.

## ICONOGRAPHY

Nenhum ícone, sprite ou fonte de ícones veio com o briefing. **Substituição sinalizada:** o sistema usa **Lucide** (traço 1.5px, sem preenchimento, 18–20px) para glifos de UI e **Simple Icons** para marcas (GitHub, LinkedIn, Behance, e-mail), ambos via CDN jsDelivr, inlinados pelo componente `Icon` para herdar `currentColor`. Escolha: Lucide tem o traço fino e geométrico coerente com hairlines de 1px; Simple Icons é a única fonte confiável para a marca do Behance.

Regras: ícone sempre monocromático em `--icon` ou `--text-primary` — marcas nunca em cor oficial. Emoji: nunca. Caracteres unicode como ícone: nunca (o travessão `—` é pontuação, não ícone). Ícone acompanha texto na maioria dos casos; quando sozinho, exige `aria-label` (ver `IconButton`).

Se você tiver um set próprio, coloque os SVGs em `assets/icons/` e troque a resolução dentro de `components/core/Icon.jsx` — é o único ponto de contato.

## Substituições a confirmar

- **Fontes:** sem binários. Space Grotesk, Inter e JetBrains Mono são carregadas do Google Fonts em `tokens/fonts.css`. Para auto-hospedar, troque por `@font-face` local.
- **Ícones:** Lucide + Simple Icons via CDN, como descrito acima.
- **Retrato de luz:** `assets/imagery/retrato-luz.png` (enviado pelo autor) é o plate do hero, com parallax ligado ao scroll e veil de silêncio sobre a metade do texto.
- **Conteúdo dos kits:** projetos, empresas, datas e métricas no site-currículo e nas peças de LinkedIn são plausíveis, porém fictícios. Substituir por conteúdo real antes de publicar.
