/* @ds-bundle: {"format":4,"namespace":"MacdsDesignSystem_3cef76","components":[{"name":"CredentialItem","sourcePath":"components/content/CredentialItem.jsx"},{"name":"SectionHeader","sourcePath":"components/content/SectionHeader.jsx"},{"name":"SocialLink","sourcePath":"components/content/SocialLink.jsx"},{"name":"StackGroup","sourcePath":"components/content/StackGroup.jsx"},{"name":"TimelineItem","sourcePath":"components/content/TimelineItem.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Divider","sourcePath":"components/core/Divider.jsx"},{"name":"Eyebrow","sourcePath":"components/core/Eyebrow.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"ThemeToggle","sourcePath":"components/core/ThemeToggle.jsx"},{"name":"Wordmark","sourcePath":"components/core/Wordmark.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"CausticBackdrop","sourcePath":"components/motion/CausticBackdrop.jsx"},{"name":"Magnetic","sourcePath":"components/motion/Magnetic.jsx"},{"name":"Marquee","sourcePath":"components/motion/Marquee.jsx"},{"name":"Parallax","sourcePath":"components/motion/Parallax.jsx"},{"name":"RefractionSurface","sourcePath":"components/motion/RefractionSurface.jsx"},{"name":"ScrollMask","sourcePath":"components/motion/ScrollMask.jsx"},{"name":"ScrollProgress","sourcePath":"components/motion/ScrollProgress.jsx"},{"name":"Shatter","sourcePath":"components/motion/Shatter.jsx"},{"name":"Fragment","sourcePath":"components/motion/Shatter.jsx"},{"name":"SweepText","sourcePath":"components/motion/SweepText.jsx"},{"name":"GlassPanel","sourcePath":"components/surfaces/GlassPanel.jsx"},{"name":"Grain","sourcePath":"components/surfaces/Grain.jsx"},{"name":"ProjectCard","sourcePath":"components/surfaces/ProjectCard.jsx"}],"sourceHashes":{"components/content/CredentialItem.jsx":"d28bc4afc943","components/content/SectionHeader.jsx":"4401f009a464","components/content/SocialLink.jsx":"bac5d50d59a1","components/content/StackGroup.jsx":"81624ab9096e","components/content/TimelineItem.jsx":"33136e8e20ab","components/core/Button.jsx":"f5ff50ad0279","components/core/Divider.jsx":"b151fb5f070e","components/core/Eyebrow.jsx":"2e435d107fb6","components/core/Icon.jsx":"1640fb051789","components/core/IconButton.jsx":"53067f82f442","components/core/Tag.jsx":"12b18c11e4e3","components/core/ThemeToggle.jsx":"20a32c14cf30","components/core/Wordmark.jsx":"968bed9c54d1","components/forms/Input.jsx":"55df773b564d","components/motion/CausticBackdrop.jsx":"04da5888b02b","components/motion/Magnetic.jsx":"0cf6a237ac96","components/motion/Marquee.jsx":"4c658f1a3716","components/motion/Parallax.jsx":"7fca28f7e75e","components/motion/RefractionSurface.jsx":"05ca843001f4","components/motion/ScrollMask.jsx":"1b72e0f61ffc","components/motion/ScrollProgress.jsx":"79e5821f81bd","components/motion/Shatter.jsx":"d75bfaccb39a","components/motion/SweepText.jsx":"d1b70fe845ea","components/surfaces/GlassPanel.jsx":"044bd6cb756d","components/surfaces/Grain.jsx":"7be29adf43a4","components/surfaces/ProjectCard.jsx":"36342f7d0653","ui_kits/linkedin/LinkedinPieces.jsx":"c224c2710077","ui_kits/site/SiteApp.jsx":"8e55a891270b","ui_kits/site/SiteExperience.jsx":"089e672fad08","ui_kits/site/SiteHero.jsx":"3815be193af9","ui_kits/site/SiteSections.jsx":"e4ca636a2655","ui_kits/site/site-data.js":"76ff517fad53"},"inlinedExternals":[],"unexposedExports":[{"name":"useScrollProgress","sourcePath":"components/motion/ScrollMask.jsx"}]} */

(() => {

const __ds_ns = (window.MacdsDesignSystem_3cef76 = window.MacdsDesignSystem_3cef76 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* macds Button — monochrome. Two levels only: `light` (lit surface, the primary CTA)
   and `ghost` (hairline). No color, no scale-on-hover: hover raises the edge light. */
function Button({
  variant = "ghost",
  size = "md",
  as = "button",
  href,
  icon,
  iconAfter,
  disabled,
  children,
  style,
  ...rest
}) {
  const pad = size === "lg" ? "18px 30px" : size === "sm" ? "10px 16px" : "14px 24px";
  const fs = size === "lg" ? "var(--text-md)" : size === "sm" ? "var(--text-xs)" : "var(--text-sm)";
  const light = variant === "light";
  const base = {
    display: "inline-flex",
    alignItems: "center",
    gap: "var(--sp-3)",
    justifyContent: "center",
    minHeight: size === "sm" ? 36 : "var(--hit-min)",
    padding: pad,
    fontFamily: "var(--font-body)",
    fontSize: fs,
    fontWeight: "var(--fw-body-medium)",
    letterSpacing: "var(--tracking-tight)",
    lineHeight: 1,
    borderRadius: "var(--radius-md)",
    cursor: disabled ? "not-allowed" : "pointer",
    textDecoration: "none",
    position: "relative",
    overflow: "hidden",
    background: light ? "var(--mono-800)" : "transparent",
    color: light ? "var(--text-inverse)" : "var(--text-primary)",
    border: light ? "1px solid var(--mono-800)" : "var(--border-hairline-strong)",
    boxShadow: light ? "var(--halo-sm)" : "var(--edge-top)",
    opacity: disabled ? 0.4 : 1,
    transition: "box-shadow var(--dur-base) var(--ease), border-color var(--dur-base) var(--ease), background var(--dur-base) var(--ease), opacity var(--dur-base) var(--ease)",
    ...style
  };
  const Tag = href ? "a" : as;
  const onEnter = e => {
    if (disabled) return;
    e.currentTarget.style.boxShadow = light ? "var(--halo-md)" : "var(--edge-top-strong)";
    if (!light) e.currentTarget.style.borderColor = "var(--border-lit)";
  };
  const onLeave = e => {
    if (disabled) return;
    e.currentTarget.style.boxShadow = light ? "var(--halo-sm)" : "var(--edge-top)";
    if (!light) e.currentTarget.style.borderColor = "var(--border-strong)";
  };
  return /*#__PURE__*/React.createElement(Tag, _extends({
    href: href,
    disabled: !href && disabled ? true : undefined,
    "aria-disabled": disabled || undefined,
    style: base,
    onMouseEnter: onEnter,
    onMouseLeave: onLeave
  }, rest), icon, children, iconAfter);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Divider.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* macds Divider — a hairline that fades at both ends. `filament` sends a pulse of pure
   light travelling along it (ambient, transform-only). */
function Divider({
  filament = false,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "separator",
    style: {
      position: "relative",
      height: 1,
      width: "100%",
      overflow: "hidden",
      background: "var(--hairline-fade)",
      ...style
    }
  }, rest), filament && /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      inset: 0,
      background: "var(--filament)",
      opacity: 0.5,
      animation: "macds-filament var(--dur-ambient) var(--ease-liquid) infinite",
      willChange: "transform"
    }
  }));
}
Object.assign(__ds_scope, { Divider });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Divider.jsx", error: String((e && e.message) || e) }); }

// components/core/Eyebrow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* macds Eyebrow — mono uppercase label with wide tracking. Optional index numeral,
   the system's section counter ("01 / sobre"). */
function Eyebrow({
  index,
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("p", _extends({
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--sp-3)",
      margin: 0,
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-label)",
      textTransform: "uppercase",
      letterSpacing: "var(--tracking-label)",
      color: "var(--text-secondary)",
      ...style
    }
  }, rest), index && /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--text-tertiary)"
    }
  }, index), index && /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      width: 28,
      height: 1,
      background: "var(--border-strong)"
    }
  }), children);
}
Object.assign(__ds_scope, { Eyebrow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Eyebrow.jsx", error: String((e && e.message) || e) }); }

// components/content/SectionHeader.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* macds SectionHeader — index + label, huge display title, optional short lead.
   The vertical space above and below is part of the component. */
function SectionHeader({
  index,
  label,
  title,
  lead,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("header", _extends({
    style: {
      display: "grid",
      gap: "var(--sp-5)",
      marginBottom: "var(--sp-8)",
      ...style
    }
  }, rest), label && /*#__PURE__*/React.createElement(__ds_scope.Eyebrow, {
    index: index
  }, label), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontFamily: "var(--font-display)",
      fontWeight: "var(--fw-display-semibold)",
      fontSize: "var(--text-d1)",
      lineHeight: "var(--leading-display)",
      letterSpacing: "var(--tracking-display)",
      color: "var(--text-primary)",
      maxWidth: "18ch"
    }
  }, title), lead && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      maxWidth: "var(--measure)",
      fontSize: "var(--text-lg)",
      lineHeight: "var(--leading-snug)",
      color: "var(--text-secondary)"
    }
  }, lead));
}
Object.assign(__ds_scope, { SectionHeader });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/SectionHeader.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* macds Icon — inlines an SVG from a CDN icon set so it inherits currentColor.
   `set="lucide"` for UI glyphs (1.5px stroke, no fill), `set="simple"` for brand marks
   (GitHub, LinkedIn, Behance). No icon binaries shipped with the brief — see readme
   ICONOGRAPHY for the substitution note. */
const SRC = {
  lucide: n => `https://cdn.jsdelivr.net/npm/lucide-static@0.428.0/icons/${n}.svg`,
  simple: n => `https://cdn.jsdelivr.net/npm/simple-icons@13.0.0/icons/${n}.svg`
};
const cache = new Map();
function Icon({
  name,
  set = "lucide",
  size = 20,
  strokeWidth = 1.5,
  style,
  ...rest
}) {
  const [svg, setSvg] = React.useState(() => cache.get(set + name) || "");
  React.useEffect(() => {
    const key = set + name;
    if (cache.has(key)) {
      setSvg(cache.get(key));
      return;
    }
    let alive = true;
    fetch(SRC[set](name)).then(r => r.ok ? r.text() : "").then(t => {
      if (!t) return;
      const clean = t.replace(/<svg([^>]*)>/, (m, a) => `<svg${a.replace(/width="[^"]*"/, "").replace(/height="[^"]*"/, "")} width="100%" height="100%" fill="${set === "simple" ? "currentColor" : "none"}" stroke="${set === "simple" ? "none" : "currentColor"}" stroke-width="${strokeWidth}">`).replace(/<title>.*?<\/title>/, "");
      cache.set(key, clean);
      if (alive) setSvg(clean);
    });
    return () => {
      alive = false;
    };
  }, [name, set, strokeWidth]);
  return /*#__PURE__*/React.createElement("span", _extends({
    "aria-hidden": "true",
    style: {
      width: size,
      height: size,
      display: "inline-block",
      flex: "0 0 auto",
      color: "currentColor",
      ...style
    },
    dangerouslySetInnerHTML: {
      __html: svg
    }
  }, rest));
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/content/CredentialItem.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* macds CredentialItem — formação e certificados row: institution, title, year, optional
   verification link. Hairline separated, no cards. */
function CredentialItem({
  title,
  org,
  year,
  href,
  style,
  ...rest
}) {
  const content = /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gap: "var(--sp-1)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: "var(--fw-display-medium)",
      fontSize: "var(--text-md)",
      letterSpacing: "var(--tracking-tight)",
      color: "var(--text-primary)"
    }
  }, title), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-sm)",
      color: "var(--text-secondary)"
    }
  }, org)), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "var(--sp-3)",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-xs)",
      color: "var(--text-tertiary)"
    }
  }, year, href && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "arrow-up-right",
    size: 14
  })));
  const base = {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: "var(--sp-5)",
    padding: "var(--sp-5) 0",
    borderTop: "var(--border-hairline)",
    minHeight: "var(--hit-min)",
    textDecoration: "none",
    ...style
  };
  return href ? /*#__PURE__*/React.createElement("a", _extends({
    href: href,
    style: base
  }, rest), content) : /*#__PURE__*/React.createElement("div", _extends({
    style: base
  }, rest), content);
}
Object.assign(__ds_scope, { CredentialItem });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/CredentialItem.jsx", error: String((e && e.message) || e) }); }

// components/content/SocialLink.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* macds SocialLink — large contact row: brand mark, handle, destination. The contact
   section is a list of these, not a grid of icon buttons. */
function SocialLink({
  network,
  label,
  handle,
  href,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("a", _extends({
    href: href,
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--sp-5)",
      padding: "var(--sp-5) 0",
      borderTop: "var(--border-hairline)",
      textDecoration: "none",
      minHeight: 72,
      transition: "padding-left var(--dur-base) var(--ease), border-color var(--dur-base) var(--ease)",
      ...style
    },
    onMouseEnter: e => {
      e.currentTarget.style.paddingLeft = "var(--sp-3)";
      e.currentTarget.style.borderColor = "var(--border-lit)";
    },
    onMouseLeave: e => {
      e.currentTarget.style.paddingLeft = "0";
      e.currentTarget.style.borderColor = "var(--border)";
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--icon)",
      display: "grid",
      placeItems: "center",
      width: 22
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    set: "simple",
    name: network,
    size: 20
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      fontFamily: "var(--font-display)",
      fontWeight: "var(--fw-display-medium)",
      fontSize: "var(--text-d3)",
      letterSpacing: "var(--tracking-tight)",
      color: "var(--text-primary)"
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-xs)",
      color: "var(--text-secondary)"
    }
  }, handle), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "arrow-up-right",
    size: 18,
    style: {
      color: "var(--icon-muted)"
    }
  }));
}
Object.assign(__ds_scope, { SocialLink });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/SocialLink.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* macds IconButton — square hairline target, 44px minimum. */
function IconButton({
  label,
  children,
  href,
  size = 44,
  disabled,
  style,
  ...rest
}) {
  const Tag = href ? "a" : "button";
  return /*#__PURE__*/React.createElement(Tag, _extends({
    href: href,
    "aria-label": label,
    title: label,
    disabled: !href && disabled ? true : undefined,
    style: {
      width: size,
      height: size,
      display: "inline-grid",
      placeItems: "center",
      background: "transparent",
      border: "var(--border-hairline)",
      borderRadius: "var(--radius-md)",
      color: "var(--icon)",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.4 : 1,
      boxShadow: "var(--edge-top)",
      transition: "box-shadow var(--dur-base) var(--ease), border-color var(--dur-base) var(--ease), color var(--dur-base) var(--ease)",
      ...style
    },
    onMouseEnter: e => {
      if (disabled) return;
      e.currentTarget.style.borderColor = "var(--border-lit)";
      e.currentTarget.style.color = "var(--text-primary)";
      e.currentTarget.style.boxShadow = "var(--edge-top-strong)";
    },
    onMouseLeave: e => {
      if (disabled) return;
      e.currentTarget.style.borderColor = "var(--border)";
      e.currentTarget.style.color = "var(--icon)";
      e.currentTarget.style.boxShadow = "var(--edge-top)";
    }
  }, rest), children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* macds Tag — hairline chip for stack items and project meta. Mono type, uppercase off. */
function Tag({
  children,
  lit = false,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      height: 30,
      padding: "0 12px",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-xs)",
      letterSpacing: "0",
      color: lit ? "var(--text-primary)" : "var(--text-secondary)",
      background: lit ? "var(--surface-2)" : "transparent",
      border: `1px solid ${lit ? "var(--border-lit)" : "var(--border)"}`,
      borderRadius: "var(--radius-sm)",
      boxShadow: lit ? "var(--edge-top)" : "none",
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/content/StackGroup.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* macds StackGroup — a competence cluster: mono heading + chips. */
function StackGroup({
  heading,
  items = [],
  lit = [],
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "grid",
      gap: "var(--sp-4)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-label)",
      textTransform: "uppercase",
      letterSpacing: "var(--tracking-label)",
      color: "var(--text-secondary)",
      fontWeight: 400
    }
  }, heading), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: "var(--sp-2)"
    }
  }, items.map(i => /*#__PURE__*/React.createElement(__ds_scope.Tag, {
    key: i,
    lit: lit.includes(i)
  }, i))));
}
Object.assign(__ds_scope, { StackGroup });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/StackGroup.jsx", error: String((e && e.message) || e) }); }

// components/content/TimelineItem.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* macds TimelineItem — experience row. Mono period on the left, role and company on the
   right, hairline rule between rows, a lit node on the spine. */
function TimelineItem({
  period,
  role,
  org,
  description,
  stack = [],
  current = false,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("li", _extends({
    style: {
      position: "relative",
      listStyle: "none",
      display: "grid",
      gridTemplateColumns: "minmax(120px,180px) 1fr",
      gap: "var(--sp-6)",
      padding: "var(--sp-6) 0",
      borderTop: "var(--border-hairline)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      top: -3,
      left: 0,
      width: 5,
      height: 5,
      borderRadius: "var(--radius-full)",
      background: current ? "var(--light-pure)" : "var(--mono-400)",
      boxShadow: current ? "var(--halo-sm)" : "none"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-xs)",
      color: "var(--text-tertiary)",
      letterSpacing: 0,
      paddingTop: 4
    }
  }, period), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gap: "var(--sp-3)"
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontFamily: "var(--font-display)",
      fontWeight: "var(--fw-display-medium)",
      fontSize: "var(--text-d3)",
      letterSpacing: "var(--tracking-tight)",
      lineHeight: "var(--leading-snug)",
      color: "var(--text-primary)"
    }
  }, role, org && /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--text-secondary)"
    }
  }, " \xB7 ", org)), description && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      maxWidth: "var(--measure)",
      fontSize: "var(--text-sm)",
      lineHeight: "var(--leading-body)",
      color: "var(--text-secondary)"
    }
  }, description), stack.length > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: "var(--sp-2)"
    }
  }, stack.map(s => /*#__PURE__*/React.createElement(__ds_scope.Tag, {
    key: s
  }, s)))));
}
Object.assign(__ds_scope, { TimelineItem });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/TimelineItem.jsx", error: String((e && e.message) || e) }); }

// components/core/ThemeToggle.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* macds ThemeToggle — flips [data-theme] on <html> between the dark system (default) and
   the paper/light system, where pure black takes the role of light. Morphs the glyph
   instead of crossfading. */
function ThemeToggle({
  target = "documentElement",
  style,
  ...rest
}) {
  const [theme, setTheme] = React.useState("dark");
  React.useEffect(() => {
    const root = target === "documentElement" ? document.documentElement : document.body;
    const saved = localStorage.getItem("macds-theme");
    if (saved) {
      setTheme(saved);
      if (saved === "light") root.setAttribute("data-theme", "light");
    }
  }, [target]);
  const flip = () => {
    const root = target === "documentElement" ? document.documentElement : document.body;
    const next = theme === "dark" ? "light" : "dark";
    setTheme(next);
    if (next === "light") root.setAttribute("data-theme", "light");else root.removeAttribute("data-theme");
    localStorage.setItem("macds-theme", next);
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    onClick: flip,
    "aria-label": theme === "dark" ? "usar tema claro" : "usar tema escuro",
    style: {
      width: 44,
      height: 44,
      display: "inline-grid",
      placeItems: "center",
      background: "transparent",
      border: "var(--border-hairline)",
      borderRadius: "var(--radius-md)",
      color: "var(--icon)",
      cursor: "pointer",
      boxShadow: "var(--edge-top)",
      transition: "border-color var(--dur-base) var(--ease), color var(--dur-base) var(--ease)",
      ...style
    },
    onMouseEnter: e => {
      e.currentTarget.style.borderColor = "var(--border-lit)";
      e.currentTarget.style.color = "var(--text-primary)";
    },
    onMouseLeave: e => {
      e.currentTarget.style.borderColor = "var(--border)";
      e.currentTarget.style.color = "var(--icon)";
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "grid",
      placeItems: "center",
      transform: `rotate(${theme === "dark" ? 0 : 180}deg)`,
      transition: "transform var(--dur-mid) var(--ease)"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: theme === "dark" ? "sun" : "moon",
    size: 18
  })));
}
Object.assign(__ds_scope, { ThemeToggle });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/ThemeToggle.jsx", error: String((e && e.message) || e) }); }

// components/core/Wordmark.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* macds Wordmark — always lowercase "macds", Space Grotesk, hard negative tracking, one
   compact block. `sweep` runs the light-sweep reveal (the site's entry animation).
   Monogram variant renders "m" for favicon/avatar use. */
function Wordmark({
  size = 40,
  monogram = false,
  sweep = false,
  as = "span",
  style,
  ...rest
}) {
  const Tag = as;
  const text = monogram ? "m" : "macds";
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (!sweep || !ref.current) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const el = ref.current;
    const g = "linear-gradient(100deg,transparent 12%,#000 42%,#000 58%,transparent 88%)";
    el.style.webkitMaskImage = g;
    el.style.maskImage = g;
    el.style.webkitMaskSize = "220% 100%";
    el.style.maskSize = "220% 100%";
    el.style.webkitMaskPosition = "150% 0";
    el.style.maskPosition = "150% 0";
    el.style.transition = "mask-position var(--dur-slow) var(--ease), -webkit-mask-position var(--dur-slow) var(--ease)";
    requestAnimationFrame(() => {
      el.style.webkitMaskPosition = "-50% 0";
      el.style.maskPosition = "-50% 0";
    });
    const t = setTimeout(() => {
      el.style.webkitMaskImage = "none";
      el.style.maskImage = "none";
    }, 900);
    return () => clearTimeout(t);
  }, [sweep]);
  return /*#__PURE__*/React.createElement(Tag, _extends({
    ref: ref,
    "aria-label": "macds",
    style: {
      display: "inline-block",
      fontFamily: "var(--font-display)",
      fontWeight: "var(--fw-display-bold)",
      fontSize: size,
      lineHeight: 0.82,
      letterSpacing: "var(--tracking-hero)",
      color: "var(--text-primary)",
      ...style
    }
  }, rest), text);
}
Object.assign(__ds_scope, { Wordmark });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Wordmark.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* macds Input — hairline underline field. Focus lights the rule; no fill change, no glow
   on the whole box. Label sits above, mono uppercase. */
function Input({
  label,
  id,
  type = "text",
  hint,
  error,
  textarea = false,
  rows = 4,
  style,
  ...rest
}) {
  const rid = id || React.useId();
  const [focus, setFocus] = React.useState(false);
  const field = {
    width: "100%",
    background: "transparent",
    border: "0",
    borderBottom: `1px solid ${error ? "var(--mono-700)" : focus ? "var(--light-70)" : "var(--border-strong)"}`,
    padding: "var(--sp-3) 0",
    color: "var(--text-primary)",
    fontFamily: "var(--font-body)",
    fontSize: "var(--text-md)",
    letterSpacing: "var(--tracking-body)",
    outline: "none",
    borderRadius: 0,
    resize: textarea ? "vertical" : undefined,
    minHeight: textarea ? undefined : "var(--hit-min)",
    transition: "border-color var(--dur-base) var(--ease)"
  };
  const Tag = textarea ? "textarea" : "input";
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gap: "var(--sp-2)",
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: rid,
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-label)",
      textTransform: "uppercase",
      letterSpacing: "var(--tracking-label)",
      color: focus ? "var(--text-primary)" : "var(--text-secondary)",
      transition: "color var(--dur-base) var(--ease)"
    }
  }, label), /*#__PURE__*/React.createElement(Tag, _extends({
    id: rid,
    type: textarea ? undefined : type,
    rows: textarea ? rows : undefined,
    style: field,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    "aria-invalid": error ? true : undefined,
    "aria-describedby": hint || error ? `${rid}-d` : undefined
  }, rest)), (hint || error) && /*#__PURE__*/React.createElement("p", {
    id: `${rid}-d`,
    style: {
      margin: 0,
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-xs)",
      color: error ? "var(--text-primary)" : "var(--text-tertiary)"
    }
  }, error || hint));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/motion/CausticBackdrop.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* macds CausticBackdrop — slow luminance movement behind the hero. Layered radial light
   plus an optional reference plate in screen blend. Transform-only animation; frozen
   below 768px and under prefers-reduced-motion. */
function CausticBackdrop({
  plate,
  intensity = 1,
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      position: "absolute",
      inset: 0,
      overflow: "hidden",
      background: "var(--canvas)",
      ...style
    },
    "aria-hidden": "true"
  }, rest), /*#__PURE__*/React.createElement("div", {
    className: "macds-static-below-md",
    style: {
      position: "absolute",
      inset: "-12%",
      background: "var(--caustic-field)",
      opacity: 0.9 * intensity,
      filter: "blur(18px)",
      animation: "macds-caustic var(--dur-ambient) ease-in-out infinite",
      willChange: "transform"
    }
  }), plate && /*#__PURE__*/React.createElement("img", {
    src: plate,
    alt: "",
    loading: "lazy",
    className: "macds-static-below-md macds-plate",
    style: {
      position: "absolute",
      inset: 0,
      width: "100%",
      height: "100%",
      objectFit: "cover",
      opacity: 0.5 * intensity,
      mixBlendMode: "screen",
      animation: "macds-caustic calc(var(--dur-ambient) * 2.4) ease-in-out infinite reverse",
      willChange: "transform"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      background: "var(--depth-inset)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "macds-grain macds-grain--local",
    style: {
      position: "absolute"
    }
  }), children);
}
Object.assign(__ds_scope, { CausticBackdrop });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/motion/CausticBackdrop.jsx", error: String((e && e.message) || e) }); }

// components/motion/Magnetic.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* macds Magnetic — the element leans toward the cursor and deforms slightly. Transform
   only; disabled under reduced motion and on touch. */
function Magnetic({
  children,
  pull = 14,
  skew = 1.4,
  as = "div",
  style,
  ...rest
}) {
  const Tag = as;
  const ref = React.useRef(null);
  const ok = () => typeof window !== "undefined" && window.matchMedia("(hover: hover)").matches && !window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  return /*#__PURE__*/React.createElement(Tag, _extends({
    ref: ref,
    style: {
      display: "inline-block",
      transition: "transform var(--dur-base) var(--ease)",
      willChange: "transform",
      ...style
    },
    onMouseMove: e => {
      if (!ok()) return;
      const r = e.currentTarget.getBoundingClientRect();
      const dx = (e.clientX - (r.left + r.width / 2)) / (r.width / 2),
        dy = (e.clientY - (r.top + r.height / 2)) / (r.height / 2);
      e.currentTarget.style.transform = `translate3d(${dx * pull}px,${dy * pull}px,0) skew(${-dx * skew}deg,${dy * skew * 0.4}deg)`;
    },
    onMouseLeave: e => {
      if (!ok()) return;
      e.currentTarget.style.transform = "none";
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Magnetic });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/motion/Magnetic.jsx", error: String((e && e.message) || e) }); }

// components/motion/Marquee.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* macds Marquee — infinite light ticker. One continuous translate on a duplicated track,
   masked to fade at both edges. Pauses on hover and under reduced motion. */
function Marquee({
  items = [],
  speed = 42,
  separator = "·",
  style,
  ...rest
}) {
  const [paused, setPaused] = React.useState(false);
  const reduce = typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const track = [...items, ...items];
  const fade = "linear-gradient(90deg,transparent,#000 8%,#000 92%,transparent)";
  return /*#__PURE__*/React.createElement("div", _extends({
    onMouseEnter: () => setPaused(true),
    onMouseLeave: () => setPaused(false),
    style: {
      overflow: "hidden",
      WebkitMaskImage: fade,
      maskImage: fade,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--sp-6)",
      width: "max-content",
      alignItems: "center",
      animation: reduce ? "none" : `macds-marquee ${speed}s linear infinite`,
      animationPlayState: paused ? "paused" : "running",
      willChange: "transform"
    }
  }, track.map((t, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "var(--sp-6)",
      fontFamily: "var(--font-display)",
      fontWeight: "var(--fw-display-medium)",
      fontSize: "var(--text-d3)",
      letterSpacing: "var(--tracking-tight)",
      color: i % 2 ? "var(--text-secondary)" : "var(--text-primary)",
      whiteSpace: "nowrap"
    }
  }, t, /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      color: "var(--text-tertiary)"
    }
  }, separator)))));
}
Object.assign(__ds_scope, { Marquee });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/motion/Marquee.jsx", error: String((e && e.message) || e) }); }

// components/motion/RefractionSurface.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* macds RefractionSurface — glass hover. An SVG feDisplacementMap distorts the whole
   subtree as the cursor approaches, and a specular highlight tracks the pointer.
   Below 768px (or reduced motion) the filter is never applied: the static surface is the
   real fallback. Used on project cards. */
let uid = 0;
function RefractionSurface({
  children,
  amount = 16,
  radius = "var(--radius-lg)",
  style,
  ...rest
}) {
  const id = React.useMemo(() => `macds-refract-${++uid}`, []);
  const host = React.useRef(null);
  const disp = React.useRef(null);
  const [pt, setPt] = React.useState({
    x: 50,
    y: 50,
    on: false
  });
  const raf = React.useRef(0);
  const enabled = () => typeof window !== "undefined" && window.matchMedia("(min-width: 769px)").matches && !window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const drive = target => {
    cancelAnimationFrame(raf.current);
    const node = disp.current;
    if (!node) return;
    const from = parseFloat(node.getAttribute("scale")) || 0;
    const t0 = performance.now(),
      d = 550;
    const step = t => {
      const p = Math.min(1, (t - t0) / d);
      const e = 1 - Math.pow(1 - p, 3);
      node.setAttribute("scale", String(from + (target - from) * e));
      if (p < 1) raf.current = requestAnimationFrame(step);
    };
    raf.current = requestAnimationFrame(step);
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    ref: host,
    style: {
      position: "relative",
      borderRadius: radius,
      isolation: "isolate",
      ...style
    },
    onMouseEnter: () => {
      if (!enabled()) return;
      host.current.style.filter = `url(#${id})`;
      drive(amount);
      setPt(p => ({
        ...p,
        on: true
      }));
    },
    onMouseLeave: () => {
      if (!enabled()) return;
      drive(0);
      setPt(p => ({
        ...p,
        on: false
      }));
      setTimeout(() => {
        if (host.current) host.current.style.filter = "none";
      }, 560);
    },
    onMouseMove: e => {
      if (!enabled()) return;
      const r = e.currentTarget.getBoundingClientRect();
      setPt({
        x: (e.clientX - r.left) / r.width * 100,
        y: (e.clientY - r.top) / r.height * 100,
        on: true
      });
    }
  }, rest), /*#__PURE__*/React.createElement("svg", {
    width: "0",
    height: "0",
    style: {
      position: "absolute"
    },
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("filter", {
    id: id,
    x: "-8%",
    y: "-8%",
    width: "116%",
    height: "116%",
    colorInterpolationFilters: "sRGB"
  }, /*#__PURE__*/React.createElement("feTurbulence", {
    type: "fractalNoise",
    baseFrequency: "0.014 0.022",
    numOctaves: "2",
    seed: "7",
    result: "n"
  }), /*#__PURE__*/React.createElement("feDisplacementMap", {
    ref: disp,
    in: "SourceGraphic",
    in2: "n",
    scale: "0",
    xChannelSelector: "R",
    yChannelSelector: "G"
  }))), children, /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      inset: 0,
      borderRadius: radius,
      pointerEvents: "none",
      background: `radial-gradient(38% 38% at ${pt.x}% ${pt.y}%, rgba(255,255,255,.14), transparent 70%)`,
      opacity: pt.on ? 1 : 0,
      transition: "opacity var(--dur-base) var(--ease)"
    }
  }));
}
Object.assign(__ds_scope, { RefractionSurface });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/motion/RefractionSurface.jsx", error: String((e && e.message) || e) }); }

// components/motion/ScrollMask.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* macds useScrollProgress — 0→1 progress of an element crossing the viewport, driven by a
   single rAF-throttled scroll listener. Returns 0 (start) under prefers-reduced-motion. */
function useScrollProgress(ref, {
  from = 1,
  to = 0.15
} = {}) {
  const [p, setP] = React.useState(0);
  React.useEffect(() => {
    if (typeof window === "undefined") return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setP(1);
      return;
    }
    let raf = 0;
    const measure = () => {
      const el = ref.current;
      if (!el) return;
      const r = el.getBoundingClientRect(),
        vh = window.innerHeight || 1;
      const start = vh * from,
        end = vh * to;
      const v = (start - r.top) / Math.max(1, start - end);
      setP(Math.min(1, Math.max(0, v)));
    };
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(measure);
    };
    measure();
    window.addEventListener("scroll", onScroll, {
      passive: true
    });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      cancelAnimationFrame(raf);
    };
  }, [ref, from, to]);
  return p;
}

/* macds ScrollMask — the light sweep bound to scroll instead of to time. The mask position
   tracks scroll progress, so the text is written by light as the page moves. Fully visible
   (mask removed) once complete and under reduced motion. */
function ScrollMask({
  children,
  as = "div",
  softness = 34,
  style,
  ...rest
}) {
  const Tag = as;
  const ref = React.useRef(null);
  const p = useScrollProgress(ref, {
    from: 0.95,
    to: 0.35
  });
  const done = p >= 1;
  const g = `linear-gradient(100deg,#000 0%,#000 ${Math.max(0, p * 100 - softness)}%,rgba(0,0,0,.25) ${p * 100}%,rgba(0,0,0,0) ${Math.min(100, p * 100 + softness * 0.4)}%)`;
  return /*#__PURE__*/React.createElement(Tag, _extends({
    ref: ref,
    style: {
      ...(done ? {} : {
        WebkitMaskImage: g,
        maskImage: g,
        WebkitMaskSize: "100% 100%",
        maskSize: "100% 100%"
      }),
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { useScrollProgress, ScrollMask });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/motion/ScrollMask.jsx", error: String((e && e.message) || e) }); }

// components/motion/Parallax.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* macds Parallax — scroll-linked translate (and optional scale) on transform only.
   Depth in a monochrome system comes from differential speed, not from color. */
function Parallax({
  children,
  distance = 80,
  scale = 0,
  as = "div",
  style,
  ...rest
}) {
  const Tag = as;
  const ref = React.useRef(null);
  const p = __ds_scope.useScrollProgress(ref, {
    from: 1.1,
    to: -0.2
  });
  const y = (p - 0.5) * -distance;
  const s = 1 + (scale ? (1 - Math.abs(p - 0.5) * 2) * scale : 0);
  return /*#__PURE__*/React.createElement(Tag, _extends({
    ref: ref,
    style: {
      transform: `translate3d(0,${y}px,0) scale(${s})`,
      willChange: "transform",
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Parallax });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/motion/Parallax.jsx", error: String((e && e.message) || e) }); }

// components/motion/ScrollProgress.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* macds ScrollProgress — a 1px filament across the top of the page whose width is the
   read position. The only always-on scroll indicator in the system. */
function ScrollProgress({
  style,
  ...rest
}) {
  const [p, setP] = React.useState(0);
  React.useEffect(() => {
    let raf = 0;
    const measure = () => {
      const h = document.documentElement.scrollHeight - window.innerHeight;
      setP(h > 0 ? window.scrollY / h : 0);
    };
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(measure);
    };
    measure();
    window.addEventListener("scroll", onScroll, {
      passive: true
    });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      cancelAnimationFrame(raf);
    };
  }, []);
  return /*#__PURE__*/React.createElement("div", _extends({
    "aria-hidden": "true",
    style: {
      position: "fixed",
      top: 0,
      left: 0,
      right: 0,
      height: 1,
      zIndex: 60,
      background: "var(--border)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      height: "100%",
      width: `${p * 100}%`,
      background: "var(--filament)",
      transformOrigin: "left"
    }
  }));
}
Object.assign(__ds_scope, { ScrollProgress });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/motion/ScrollProgress.jsx", error: String((e && e.message) || e) }); }

// components/motion/Shatter.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* macds Shatter — fragmentação: the element breaks into vertical shards that drift apart
   and dim as it leaves the viewport. Clip-path + transform only; no fade of the whole box. */
function Shatter({
  children,
  shards = 7,
  spread = 90,
  style,
  ...rest
}) {
  const ref = React.useRef(null);
  const p = __ds_scope.useScrollProgress(ref, {
    from: 0.15,
    to: -0.55
  });
  const out = 1 - p; // 1 while in view, → 0 as it exits upward
  const k = Math.max(0, Math.min(1, 1 - out));
  const list = Array.from({
    length: shards
  }, (_, i) => i);
  const measure = 100 / shards;
  return /*#__PURE__*/React.createElement("div", _extends({
    ref: ref,
    style: {
      position: "relative",
      ...style
    }
  }, rest), list.map(i => {
    const dir = i % 2 ? 1 : -1;
    const seed = i * 37 % 11 / 11;
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      "aria-hidden": i > 0 ? "true" : undefined,
      style: {
        ...(i === 0 ? {} : {
          position: "absolute",
          inset: 0
        }),
        clipPath: `polygon(${i * measure}% 0,${(i + 1) * measure}% 0,${(i + 1) * measure}% 100%,${i * measure}% 100%)`,
        transform: `translate3d(${dir * k * spread * (0.4 + seed)}px,${-k * spread * seed * 0.6}px,0) rotate(${dir * k * 2.5 * seed}deg)`,
        opacity: 1 - k * 0.85,
        willChange: "transform,opacity"
      }
    }, children);
  }));
}

/* legacy alias — do not remove; consumers may still reference the old name */
const Fragment = Shatter;
Object.assign(__ds_scope, { Shatter, Fragment });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/motion/Shatter.jsx", error: String((e && e.message) || e) }); }

// components/motion/SweepText.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* macds SweepText — the signature reveal. A white gradient crosses a text mask, per
   character, with the system easing. NOT a fade or a slide. Static and fully legible
   under prefers-reduced-motion. */
function SweepText({
  children,
  as = "span",
  delay = 0,
  stagger = 26,
  style,
  ...rest
}) {
  const Tag = as;
  /* children may arrive as a string, an array, or a wrapped node depending on how the
     component is mounted — flatten to text, and fall back to rendering as-is. */
  const flatten = c => React.Children.toArray(c).map(n => typeof n === "string" || typeof n === "number" ? String(n) : n && n.props ? flatten(n.props.children) : "").join("");
  const text = flatten(children);
  const reduce = typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const [on, setOn] = React.useState(reduce);
  React.useEffect(() => {
    if (reduce) return;
    const t = setTimeout(() => setOn(true), delay);
    return () => clearTimeout(t);
  }, [delay, reduce]);
  if (!text) return /*#__PURE__*/React.createElement(Tag, _extends({
    style: style
  }, rest), children);
  return /*#__PURE__*/React.createElement(Tag, _extends({
    style: {
      display: "inline-block",
      ...style
    }
  }, rest), text.split("").map((ch, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    "aria-hidden": ch === " " ? "true" : undefined,
    style: {
      display: "inline-block",
      whiteSpace: "pre",
      color: on ? "var(--text-primary)" : "transparent",
      textShadow: on ? "none" : "0 0 24px rgba(255,255,255,.55)",
      transform: on ? "none" : "translate3d(0,0.14em,0)",
      transition: `color var(--dur-mid) var(--ease) ${i * stagger}ms, transform var(--dur-mid) var(--ease) ${i * stagger}ms, text-shadow var(--dur-slow) var(--ease) ${i * stagger}ms`
    }
  }, ch)));
}
Object.assign(__ds_scope, { SweepText });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/motion/SweepText.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/GlassPanel.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* macds GlassPanel — dark glass: blurred backdrop, light top edge, no diffuse shadow. */
function GlassPanel({
  children,
  radius = "var(--radius-lg)",
  padding = "var(--sp-6)",
  strong = false,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      position: "relative",
      padding,
      borderRadius: radius,
      background: `var(--glass-bg), ${strong ? "var(--surface-2)" : "var(--surface-glass)"}`,
      backdropFilter: `blur(${strong ? "var(--glass-blur-strong)" : "var(--glass-blur)"}) saturate(0)`,
      WebkitBackdropFilter: `blur(${strong ? "var(--glass-blur-strong)" : "var(--glass-blur)"}) saturate(0)`,
      border: "1px solid var(--glass-border)",
      boxShadow: "var(--edge-top), var(--depth-drop)",
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { GlassPanel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/GlassPanel.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/Grain.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* macds Grain — the mandatory 4% noise overlay. Fixed by default (whole page), local when
   scoped to a surface. Without it the black reads dead and gradients band in compression. */
function Grain({
  local = false,
  opacity,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    "aria-hidden": "true",
    className: local ? "macds-grain macds-grain--local" : "macds-grain",
    style: {
      opacity,
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { Grain });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/Grain.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/ProjectCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* macds ProjectCard — image plate on top, hairline surface below, refraction on hover.
   Text always sits on solid surface, never over the plate. */
function ProjectCard({
  title,
  year,
  summary,
  stack = [],
  image,
  href = "#",
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.RefractionSurface, {
    radius: "var(--radius-lg)",
    style: style
  }, /*#__PURE__*/React.createElement("a", _extends({
    href: href,
    style: {
      display: "block",
      textDecoration: "none",
      borderRadius: "var(--radius-lg)",
      overflow: "hidden",
      background: "var(--surface-1)",
      border: "var(--border-hairline)",
      boxShadow: "var(--edge-top)"
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      aspectRatio: "16 / 10",
      background: "var(--mono-050)",
      overflow: "hidden"
    }
  }, image && /*#__PURE__*/React.createElement("img", {
    className: "macds-plate",
    src: image,
    alt: "",
    loading: "lazy",
    style: {
      width: "100%",
      height: "100%",
      objectFit: "cover"
    }
  }), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      inset: 0,
      background: "var(--silence-veil-bottom)",
      opacity: 0.55
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "var(--sp-5) var(--sp-5) var(--sp-6)",
      display: "grid",
      gap: "var(--sp-4)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "baseline",
      justifyContent: "space-between",
      gap: "var(--sp-4)"
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontFamily: "var(--font-display)",
      fontWeight: "var(--fw-display-medium)",
      fontSize: "var(--text-d3)",
      letterSpacing: "var(--tracking-tight)",
      lineHeight: "var(--leading-snug)",
      color: "var(--text-primary)"
    }
  }, title), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-xs)",
      color: "var(--text-tertiary)"
    }
  }, year)), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: "var(--text-sm)",
      lineHeight: "var(--leading-body)",
      color: "var(--text-secondary)"
    }
  }, summary), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: "var(--sp-2)"
    }
  }, stack.map(s => /*#__PURE__*/React.createElement(__ds_scope.Tag, {
    key: s
  }, s))), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "var(--sp-2)",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-label)",
      textTransform: "uppercase",
      letterSpacing: "var(--tracking-label)",
      color: "var(--text-primary)"
    }
  }, "ver projeto ", /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "arrow-up-right",
    size: 14
  })))));
}
Object.assign(__ds_scope, { ProjectCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/ProjectCard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/linkedin/LinkedinPieces.jsx
try { (() => {
const NS = window.MacdsDesignSystem_3cef76 || {};
/* Tolerant lookup, declared per file: the compiled bundle can trail the sources by a
   revision, and each file is also evaluated standalone by the compiler. */
const pick = (...names) => {
  for (const n of names) {
    if (NS[n]) return NS[n];
  }
  return ({
    children
  }) => children ?? null;
};
const Wordmark = pick("Wordmark"),
  Eyebrow = pick("Eyebrow"),
  Grain = pick("Grain"),
  Tag = pick("Tag"),
  Icon = pick("Icon"),
  Divider = pick("Divider");

/* Artboard — a real-pixel canvas (1080×1350, 1080×1080, 1584×396) scaled to fit the
   viewport. Body type never below 28px at 1080 width. */
function Artboard({
  w,
  h,
  children,
  scale,
  theme
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: w * scale,
      height: h * scale,
      flex: "0 0 auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    "data-theme": theme === "light" ? "light" : undefined,
    style: {
      width: w,
      height: h,
      transform: `scale(${scale})`,
      transformOrigin: "top left",
      position: "relative",
      overflow: "hidden",
      background: "var(--canvas)",
      border: "var(--border-hairline)"
    }
  }, children, /*#__PURE__*/React.createElement(Grain, {
    local: true,
    opacity: 0.05
  })));
}
const plate = n => `../../assets/imagery/${n}.png`;
const SLIDES = [{
  kind: "capa",
  eyebrow: "carrossel · 01",
  title: "por que seu\nfront-end está\nlento",
  body: "Cinco causas que aparecem em quase todo projeto que eu recebo para consertar.",
  plate: "formas-liquidas"
}, {
  kind: "conteudo",
  eyebrow: "01",
  title: "imagem sem\nlazy-load",
  body: "Cada imagem acima da dobra disputa banda com o que o usuário precisa ler primeiro. Carregue depois o que está fora da tela.",
  metric: "−1,4s de LCP"
}, {
  kind: "conteudo",
  eyebrow: "02",
  title: "animação em\npropriedade\nerrada",
  body: "Animar width, top ou box-shadow força layout a cada frame. Só transform e opacity chegam a 60fps com folga.",
  metric: "60fps estáveis"
}, {
  kind: "conteudo",
  eyebrow: "03",
  title: "webgl antes\ndo primeiro\npaint",
  body: "Shader é segunda camada. Ele entra depois que o texto já está legível na tela — nunca bloqueando o render.",
  metric: "sem pré-loader"
}, {
  kind: "fecho",
  eyebrow: "carrossel · 05",
  title: "quer o\nchecklist\ncompleto?",
  body: "Comente “perf” e eu te mando. Trabalho com interface e performance no mesmo commit.",
  plate: "vidro-refracao"
}];
function CarouselSlide({
  s,
  index,
  total,
  scale,
  theme
}) {
  const cover = s.kind !== "conteudo";
  return /*#__PURE__*/React.createElement(Artboard, {
    w: 1080,
    h: 1350,
    scale: scale,
    theme: theme
  }, cover && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("img", {
    className: "macds-plate",
    src: plate(s.plate),
    alt: "",
    style: {
      position: "absolute",
      inset: 0,
      width: "100%",
      height: "100%",
      objectFit: "cover",
      opacity: 0.62
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      background: "var(--silence-veil-bottom)"
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      padding: 88,
      display: "grid",
      gridTemplateRows: "auto 1fr auto",
      gap: 40
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement(Wordmark, {
    size: 44
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 28,
      letterSpacing: "0.14em",
      textTransform: "uppercase",
      color: "var(--text-secondary)"
    }
  }, s.eyebrow)), /*#__PURE__*/React.createElement("div", {
    style: {
      alignSelf: cover ? "end" : "center",
      display: "grid",
      gap: 40
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontFamily: "var(--font-display)",
      fontWeight: 700,
      fontSize: cover ? 132 : 108,
      lineHeight: 0.92,
      letterSpacing: "-0.05em",
      color: "var(--text-primary)",
      whiteSpace: "pre-line"
    }
  }, s.title), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 34,
      lineHeight: 1.5,
      color: "var(--text-secondary)",
      maxWidth: "26ch"
    }
  }, s.body), s.metric && /*#__PURE__*/React.createElement("span", {
    style: {
      justifySelf: "start",
      fontFamily: "var(--font-mono)",
      fontSize: 30,
      padding: "16px 26px",
      border: "1px solid var(--border-lit)",
      borderRadius: 8,
      color: "var(--text-primary)",
      background: "var(--surface-2)",
      boxShadow: "var(--edge-top)"
    }
  }, s.metric)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      borderTop: "var(--border-hairline)",
      paddingTop: 32
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 28,
      color: "var(--text-tertiary)"
    }
  }, "matheus alves \xB7 front-end"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 28,
      color: "var(--text-secondary)"
    }
  }, String(index + 1).padStart(2, "0"), "/", String(total).padStart(2, "0")))));
}
function PostSquare({
  scale,
  theme
}) {
  return /*#__PURE__*/React.createElement(Artboard, {
    w: 1080,
    h: 1080,
    scale: scale,
    theme: theme
  }, /*#__PURE__*/React.createElement("img", {
    className: "macds-plate",
    src: plate("curvas-metalicas"),
    alt: "",
    style: {
      position: "absolute",
      inset: 0,
      width: "100%",
      height: "100%",
      objectFit: "cover",
      opacity: 0.7
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      background: "var(--silence-veil)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      padding: 88,
      display: "grid",
      gridTemplateRows: "auto 1fr auto",
      gap: 32
    }
  }, /*#__PURE__*/React.createElement(Wordmark, {
    size: 44
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      alignSelf: "center",
      display: "grid",
      gap: 36,
      maxWidth: 620
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 28,
      letterSpacing: "0.14em",
      textTransform: "uppercase",
      color: "var(--text-secondary)"
    }
  }, "post \xB7 nota t\xE9cnica"), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontFamily: "var(--font-display)",
      fontWeight: 700,
      fontSize: 116,
      lineHeight: 0.92,
      letterSpacing: "-0.05em",
      color: "var(--text-primary)"
    }
  }, "luz n\xE3o \xE9", /*#__PURE__*/React.createElement("br", null), "cor"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 34,
      lineHeight: 1.5,
      color: "var(--text-secondary)"
    }
  }, "Num sistema monocrom\xE1tico o branco puro \xE9 reservado para aresta, halo e fio de luz. Texto vive em #F2F2F4.")), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 28,
      color: "var(--text-tertiary)"
    }
  }, "macds \xB7 design system pessoal")));
}
function BannerWide({
  scale,
  theme
}) {
  return /*#__PURE__*/React.createElement(Artboard, {
    w: 1584,
    h: 396,
    scale: scale,
    theme: theme
  }, /*#__PURE__*/React.createElement("img", {
    className: "macds-plate",
    src: plate("luz-e-estrutura"),
    alt: "",
    style: {
      position: "absolute",
      right: 0,
      top: 0,
      height: "100%",
      width: "52%",
      objectFit: "cover",
      opacity: 0.72
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      background: "var(--silence-veil)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      padding: "56px 72px",
      display: "grid",
      alignContent: "center",
      gap: 20,
      maxWidth: 900
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontFamily: "var(--font-display)",
      fontWeight: 700,
      fontSize: 84,
      lineHeight: 0.94,
      letterSpacing: "-0.05em",
      color: "var(--text-primary)"
    }
  }, "matheus alves"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontFamily: "var(--font-mono)",
      fontSize: 30,
      color: "var(--text-secondary)"
    }
  }, "desenvolvedor front-end \xB7 designer de interfaces")));
}
function LinkedinApp() {
  const [piece, setPiece] = React.useState("carrossel");
  const [theme, setTheme] = React.useState("dark");
  const [i, setI] = React.useState(0);
  const scale = piece === "banner" ? 0.42 : 0.3;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: "100vh",
      padding: "32px var(--gutter) 64px",
      display: "grid",
      gap: 32,
      justifyItems: "center",
      alignContent: "start"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      alignItems: "center",
      flexWrap: "wrap",
      justifyContent: "center"
    }
  }, [["carrossel", "carrossel 1080×1350"], ["post", "post 1080×1080"], ["banner", "banner 1584×396"]].map(([k, l]) => /*#__PURE__*/React.createElement("button", {
    key: k,
    onClick: () => setPiece(k),
    "aria-pressed": piece === k,
    style: {
      background: "none",
      border: 0,
      padding: 0,
      cursor: "pointer"
    }
  }, /*#__PURE__*/React.createElement(Tag, {
    lit: piece === k
  }, l))), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      width: 1,
      height: 22,
      background: "var(--border)",
      margin: "0 6px"
    }
  }), [["dark", "escuro"], ["light", "claro"]].map(([k, l]) => /*#__PURE__*/React.createElement("button", {
    key: k,
    onClick: () => setTheme(k),
    "aria-pressed": theme === k,
    style: {
      background: "none",
      border: 0,
      padding: 0,
      cursor: "pointer"
    }
  }, /*#__PURE__*/React.createElement(Tag, {
    lit: theme === k
  }, l)))), piece === "carrossel" && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(CarouselSlide, {
    s: SLIDES[i],
    index: i,
    total: SLIDES.length,
    scale: scale,
    theme: theme
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setI(v => Math.max(0, v - 1)),
    disabled: i === 0,
    "aria-label": "slide anterior",
    style: btn
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "arrow-left",
    size: 18
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-xs)",
      color: "var(--text-secondary)",
      minWidth: 56,
      textAlign: "center"
    }
  }, i + 1, " / ", SLIDES.length), /*#__PURE__*/React.createElement("button", {
    onClick: () => setI(v => Math.min(SLIDES.length - 1, v + 1)),
    disabled: i === SLIDES.length - 1,
    "aria-label": "pr\xF3ximo slide",
    style: btn
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "arrow-right",
    size: 18
  })))), piece === "post" && /*#__PURE__*/React.createElement(PostSquare, {
    scale: scale,
    theme: theme
  }), piece === "banner" && /*#__PURE__*/React.createElement(BannerWide, {
    scale: scale,
    theme: theme
  }));
}
const btn = {
  width: 44,
  height: 44,
  display: "grid",
  placeItems: "center",
  background: "transparent",
  border: "var(--border-hairline)",
  borderRadius: "var(--radius-md)",
  color: "var(--icon)",
  cursor: "pointer"
};
const liRoot = document.getElementById("root");
if (liRoot) ReactDOM.createRoot(liRoot).render(/*#__PURE__*/React.createElement(LinkedinApp, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/linkedin/LinkedinPieces.jsx", error: String((e && e.message) || e) }); }

// ui_kits/site/SiteApp.jsx
try { (() => {
const NS = window.MacdsDesignSystem_3cef76 || {};
/* Tolerant lookup, declared per file: the compiled bundle can trail the sources by a
   revision, and each file is also evaluated standalone by the compiler. */
const pick = (...names) => {
  for (const n of names) {
    if (NS[n]) return NS[n];
  }
  return ({
    children
  }) => children ?? null;
};
const Grain = pick("Grain"),
  ScrollProgress = pick("ScrollProgress");

/* Light source bound to scroll: one fixed luminance layer whose position rotates as the
   page moves. Transform/background-position only, and frozen under reduced motion. */
function ScrollLight() {
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    let raf = 0;
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const p = window.scrollY / Math.max(1, document.body.scrollHeight - window.innerHeight);
        const a = p * Math.PI * 2;
        if (ref.current) ref.current.style.transform = `translate3d(${Math.cos(a) * 12}%,${Math.sin(a) * 14}%,0)`;
      });
    };
    window.addEventListener("scroll", onScroll, {
      passive: true
    });
    return () => {
      window.removeEventListener("scroll", onScroll);
      cancelAnimationFrame(raf);
    };
  }, []);
  return /*#__PURE__*/React.createElement("div", {
    ref: ref,
    "aria-hidden": "true",
    style: {
      position: "fixed",
      inset: "-25%",
      zIndex: 0,
      pointerEvents: "none",
      willChange: "transform",
      background: "radial-gradient(42% 34% at 62% 38%, rgba(255,255,255,.055), transparent 68%)"
    }
  });
}
function SiteApp() {
  const [active, setActive] = React.useState("sobre");
  React.useEffect(() => {
    const ids = window.SITE.sections.map(s => s.id);
    const io = new IntersectionObserver(entries => {
      entries.forEach(e => {
        if (e.isIntersecting) setActive(e.target.id);
      });
    }, {
      rootMargin: "-45% 0px -50% 0px"
    });
    ids.forEach(id => {
      const el = document.getElementById(id);
      if (el) io.observe(el);
    });
    return () => io.disconnect();
  }, []);
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(ScrollProgress, null), /*#__PURE__*/React.createElement(ScrollLight, null), /*#__PURE__*/React.createElement(window.SiteNav, {
    active: active
  }), /*#__PURE__*/React.createElement("main", {
    style: {
      position: "relative",
      zIndex: 1
    }
  }, /*#__PURE__*/React.createElement(window.SiteHero, null), /*#__PURE__*/React.createElement(window.SiteAbout, null), /*#__PURE__*/React.createElement(window.SiteStack, null), /*#__PURE__*/React.createElement(window.SiteProjects, null), /*#__PURE__*/React.createElement(window.SiteTimeline, null), /*#__PURE__*/React.createElement(window.SiteCredentials, null), /*#__PURE__*/React.createElement(window.SiteContact, null)), /*#__PURE__*/React.createElement(window.SiteFooter, null), /*#__PURE__*/React.createElement(Grain, null));
}
const siteRoot = document.getElementById("root");
if (siteRoot) ReactDOM.createRoot(siteRoot).render(/*#__PURE__*/React.createElement(SiteApp, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/site/SiteApp.jsx", error: String((e && e.message) || e) }); }

// ui_kits/site/SiteExperience.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const NS = window.MacdsDesignSystem_3cef76 || {};
/* Tolerant lookup, declared per file: the compiled bundle can trail the sources by a
   revision, and each file is also evaluated standalone by the compiler. */
const pick = (...names) => {
  for (const n of names) {
    if (NS[n]) return NS[n];
  }
  return ({
    children
  }) => children ?? null;
};
const SectionHeader = pick("SectionHeader"),
  TimelineItem = pick("TimelineItem"),
  CredentialItem = pick("CredentialItem"),
  SocialLink = pick("SocialLink"),
  Input = pick("Input"),
  Button = pick("Button"),
  Wordmark = pick("Wordmark"),
  Divider = pick("Divider"),
  Icon = pick("Icon"),
  Eyebrow = pick("Eyebrow"),
  Magnetic = pick("Magnetic"),
  ScrollMask = pick("ScrollMask"),
  Shatter = pick("Shatter", "Fragment");
function SiteTimeline() {
  return /*#__PURE__*/React.createElement(window.Section, {
    id: "experiencia"
  }, /*#__PURE__*/React.createElement(ScrollMask, null, /*#__PURE__*/React.createElement(SectionHeader, {
    index: "04",
    label: "experi\xEAncia",
    title: "sete anos entre desenho e c\xF3digo"
  })), /*#__PURE__*/React.createElement("ul", {
    style: {
      margin: 0,
      padding: 0
    }
  }, window.SITE.experience.map(e => /*#__PURE__*/React.createElement(TimelineItem, _extends({
    key: e.period
  }, e)))));
}
function SiteCredentials() {
  return /*#__PURE__*/React.createElement(window.Section, {
    id: "formacao"
  }, /*#__PURE__*/React.createElement(ScrollMask, null, /*#__PURE__*/React.createElement(SectionHeader, {
    index: "05",
    label: "forma\xE7\xE3o e certificados",
    title: "onde aprendi o que uso"
  })), /*#__PURE__*/React.createElement("div", null, window.SITE.credentials.map(c => /*#__PURE__*/React.createElement(CredentialItem, _extends({
    key: c.title
  }, c)))));
}
function SiteContact() {
  const [sent, setSent] = React.useState(false);
  return /*#__PURE__*/React.createElement(window.Section, {
    id: "contato"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "minmax(0,1fr) minmax(0,1fr)",
      gap: "var(--sp-9)"
    },
    className: "site-two-col"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(SectionHeader, {
    index: "06",
    label: "contato",
    title: "dispon\xEDvel para conversar",
    lead: "Respondo em at\xE9 dois dias \xFAteis."
  }), /*#__PURE__*/React.createElement("div", null, window.SITE.contacts.map(c => /*#__PURE__*/React.createElement(SocialLink, _extends({
    key: c.label
  }, c))))), /*#__PURE__*/React.createElement("form", {
    onSubmit: e => {
      e.preventDefault();
      setSent(true);
    },
    style: {
      display: "grid",
      gap: "var(--sp-6)",
      alignContent: "start",
      paddingTop: "var(--sp-8)"
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "nome",
    placeholder: "como te chamo",
    required: true
  }), /*#__PURE__*/React.createElement(Input, {
    label: "e-mail",
    type: "email",
    placeholder: "voce@empresa.com",
    required: true
  }), /*#__PURE__*/React.createElement(Input, {
    label: "mensagem",
    textarea: true,
    rows: 4,
    placeholder: "o que voc\xEA precisa construir"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--sp-5)"
    }
  }, /*#__PURE__*/React.createElement(Magnetic, {
    pull: 8
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "light",
    type: "submit",
    iconAfter: /*#__PURE__*/React.createElement(Icon, {
      name: "arrow-up-right",
      size: 16
    })
  }, "enviar mensagem")), sent && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-xs)",
      color: "var(--text-secondary)"
    }
  }, "mensagem registrada \xB7 prot\xF3tipo")))));
}
function SiteFooter() {
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      padding: "var(--sp-8) var(--gutter) var(--sp-7)",
      maxWidth: "var(--container)",
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement(Divider, {
    filament: true
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-end",
      justifyContent: "space-between",
      gap: "var(--sp-6)",
      paddingTop: "var(--sp-7)",
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement(Shatter, {
    shards: 6,
    spread: 70
  }, /*#__PURE__*/React.createElement(Wordmark, {
    size: 64
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gap: "var(--sp-2)",
      textAlign: "right"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-xs)",
      color: "var(--text-secondary)"
    }
  }, window.SITE.fullName), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-xs)",
      color: "var(--text-tertiary)"
    }
  }, window.SITE.location, " \xB7 2026"))));
}
Object.assign(window, {
  SiteTimeline,
  SiteCredentials,
  SiteContact,
  SiteFooter
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/site/SiteExperience.jsx", error: String((e && e.message) || e) }); }

// ui_kits/site/SiteHero.jsx
try { (() => {
const NS = window.MacdsDesignSystem_3cef76 || {};
/* Tolerant lookup, declared per file: the compiled bundle can trail the sources by a
   revision, and each file is also evaluated standalone by the compiler. */
const pick = (...names) => {
  for (const n of names) {
    if (NS[n]) return NS[n];
  }
  return ({
    children
  }) => children ?? null;
};
const Wordmark = pick("Wordmark"),
  Button = pick("Button"),
  Icon = pick("Icon"),
  Magnetic = pick("Magnetic"),
  CausticBackdrop = pick("CausticBackdrop"),
  Eyebrow = pick("Eyebrow"),
  ThemeToggle = pick("ThemeToggle"),
  Parallax = pick("Parallax"),
  Marquee = pick("Marquee");

/* Fixed hairline nav. Lowercase links, mono, no background until scrolled. */
function SiteNav({
  active
}) {
  const [lit, setLit] = React.useState(false);
  React.useEffect(() => {
    const onScroll = () => setLit(window.scrollY > 40);
    window.addEventListener("scroll", onScroll, {
      passive: true
    });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: "fixed",
      top: 0,
      left: 0,
      right: 0,
      zIndex: 50,
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "var(--sp-4) var(--gutter)",
      background: lit ? "var(--surface-glass)" : "transparent",
      backdropFilter: lit ? "blur(14px) saturate(0)" : "none",
      borderBottom: lit ? "var(--border-hairline)" : "1px solid transparent",
      transition: "background var(--dur-base) var(--ease), border-color var(--dur-base) var(--ease)"
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#top",
    style: {
      lineHeight: 0
    }
  }, /*#__PURE__*/React.createElement(Wordmark, {
    size: 26
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--sp-5)"
    }
  }, /*#__PURE__*/React.createElement("nav", {
    "aria-label": "se\xE7\xF5es",
    style: {
      display: "flex",
      gap: "var(--sp-5)",
      alignItems: "center"
    }
  }, window.SITE.sections.map(s => /*#__PURE__*/React.createElement("a", {
    key: s.id,
    href: `#${s.id}`,
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-label)",
      textTransform: "uppercase",
      letterSpacing: "var(--tracking-label)",
      color: active === s.id ? "var(--text-primary)" : "var(--text-secondary)",
      padding: "10px 0",
      transition: "color var(--dur-base) var(--ease)"
    },
    className: "site-nav-link"
  }, s.label))), /*#__PURE__*/React.createElement(ThemeToggle, null)));
}

/* Hero — name, role, dual CTA on a solid zona de silêncio at the left; the light portrait
   occupies the right half with scroll-linked parallax over the animated caustic field.
   Text is present without waiting for animation. */
function SiteHero() {
  return /*#__PURE__*/React.createElement("section", {
    id: "top",
    style: {
      position: "relative",
      minHeight: "100svh",
      display: "grid",
      alignContent: "center",
      overflow: "hidden",
      paddingTop: "calc(var(--sp-8) + var(--sp-6))",
      paddingBottom: "var(--sp-10)"
    }
  }, /*#__PURE__*/React.createElement(CausticBackdrop, {
    plate: "../../assets/imagery/formas-liquidas.png",
    intensity: 0.55
  }), /*#__PURE__*/React.createElement(Parallax, {
    distance: 110,
    scale: 0.06,
    as: "figure",
    className: "site-hero-portrait",
    style: {
      position: "absolute",
      top: 0,
      right: 0,
      bottom: 0,
      width: "58%",
      margin: 0,
      zIndex: 0
    }
  }, /*#__PURE__*/React.createElement("img", {
    className: "macds-plate",
    src: "../../assets/imagery/retrato-luz.png",
    alt: "",
    loading: "eager",
    fetchpriority: "high",
    style: {
      width: "100%",
      height: "112%",
      objectFit: "cover",
      objectPosition: "50% 18%"
    }
  }), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      inset: 0,
      background: "var(--silence-veil)"
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      zIndex: 1,
      padding: "0 var(--gutter)",
      maxWidth: "var(--container)",
      margin: "0 auto",
      width: "100%"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "macds-silence",
    style: {
      display: "grid",
      gap: "var(--sp-6)",
      maxWidth: "22ch"
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, window.SITE.location), /*#__PURE__*/React.createElement("h1", {
    className: "macds-hero",
    style: {
      margin: 0
    }
  }, "matheus", /*#__PURE__*/React.createElement("br", null), "alves"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-sm)",
      color: "var(--text-secondary)",
      letterSpacing: 0
    }
  }, window.SITE.role), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--sp-3)",
      flexWrap: "wrap",
      marginTop: "var(--sp-3)"
    }
  }, /*#__PURE__*/React.createElement(Magnetic, {
    pull: 10
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "light",
    size: "lg",
    href: "#projetos",
    iconAfter: /*#__PURE__*/React.createElement(Icon, {
      name: "arrow-down-right",
      size: 16
    })
  }, "ver projetos")), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "lg",
    href: "#contato",
    iconAfter: /*#__PURE__*/React.createElement(Icon, {
      name: "download",
      size: 16
    })
  }, "baixar CV")))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      right: 0,
      bottom: 0,
      zIndex: 1,
      borderTop: "var(--border-hairline)",
      padding: "var(--sp-4) 0",
      background: "linear-gradient(0deg,var(--canvas),transparent)"
    }
  }, /*#__PURE__*/React.createElement(Marquee, {
    items: ["react", "typescript", "gsap", "webgl", "design systems", "acessibilidade", "performance"],
    speed: 48
  })));
}
Object.assign(window, {
  SiteNav,
  SiteHero
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/site/SiteHero.jsx", error: String((e && e.message) || e) }); }

// ui_kits/site/SiteSections.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const NS = window.MacdsDesignSystem_3cef76 || {};
/* Tolerant lookup, declared per file: the compiled bundle can trail the sources by a
   revision, and each file is also evaluated standalone by the compiler. */
const pick = (...names) => {
  for (const n of names) {
    if (NS[n]) return NS[n];
  }
  return ({
    children
  }) => children ?? null;
};
const SectionHeader = pick("SectionHeader"),
  StackGroup = pick("StackGroup"),
  Divider = pick("Divider"),
  ProjectCard = pick("ProjectCard"),
  Tag = pick("Tag"),
  Eyebrow = pick("Eyebrow"),
  ScrollMask = pick("ScrollMask");
function Section({
  id,
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("section", {
    id: id,
    style: {
      padding: "var(--section-y) var(--gutter)",
      maxWidth: "var(--container)",
      margin: "0 auto",
      ...style
    }
  }, children);
}
function SiteAbout() {
  return /*#__PURE__*/React.createElement(Section, {
    id: "sobre"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "minmax(0,1fr) minmax(0,1.1fr)",
      gap: "var(--sp-9)",
      alignItems: "start"
    },
    className: "site-two-col"
  }, /*#__PURE__*/React.createElement(ScrollMask, null, /*#__PURE__*/React.createElement(SectionHeader, {
    index: "01",
    label: "sobre",
    title: "desenho e implemento a mesma interface",
    style: {
      marginBottom: 0
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gap: "var(--sp-5)"
    }
  }, window.SITE.about.map((p, i) => /*#__PURE__*/React.createElement("p", {
    key: i,
    style: {
      margin: 0,
      fontSize: i === 0 ? "var(--text-lg)" : "var(--text-md)",
      lineHeight: i === 0 ? "var(--leading-snug)" : "var(--leading-body)",
      color: i === 0 ? "var(--text-primary)" : "var(--text-secondary)",
      maxWidth: "var(--measure)"
    }
  }, p)))));
}
function SiteStack() {
  return /*#__PURE__*/React.createElement(Section, {
    id: "stack"
  }, /*#__PURE__*/React.createElement(ScrollMask, null, /*#__PURE__*/React.createElement(SectionHeader, {
    index: "02",
    label: "stack e compet\xEAncias",
    title: "ferramentas que uso todos os dias"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit,minmax(220px,1fr))",
      gap: "var(--sp-7)"
    }
  }, window.SITE.stack.map(g => /*#__PURE__*/React.createElement(StackGroup, {
    key: g.heading,
    heading: g.heading,
    items: g.items,
    lit: g.lit
  }))));
}
function SiteProjects() {
  const [filter, setFilter] = React.useState("todos");
  const all = window.SITE.projects;
  const tags = ["todos", ...new Set(all.flatMap(p => p.stack))].slice(0, 7);
  const shown = filter === "todos" ? all : all.filter(p => p.stack.includes(filter));
  return /*#__PURE__*/React.createElement(Section, {
    id: "projetos"
  }, /*#__PURE__*/React.createElement(ScrollMask, null, /*#__PURE__*/React.createElement(SectionHeader, {
    index: "03",
    label: "projetos",
    title: "quatro pe\xE7as que aguentaram produ\xE7\xE3o",
    lead: "Filtre por tecnologia."
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--sp-2)",
      flexWrap: "wrap",
      marginBottom: "var(--sp-7)"
    }
  }, tags.map(t => /*#__PURE__*/React.createElement("button", {
    key: t,
    onClick: () => setFilter(t),
    style: {
      background: "none",
      border: 0,
      padding: 0,
      cursor: "pointer"
    },
    "aria-pressed": filter === t
  }, /*#__PURE__*/React.createElement(Tag, {
    lit: filter === t
  }, t)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit,minmax(320px,1fr))",
      gap: "var(--sp-6)"
    }
  }, shown.map(p => /*#__PURE__*/React.createElement(ProjectCard, _extends({
    key: p.title
  }, p)))));
}
Object.assign(window, {
  Section,
  SiteAbout,
  SiteStack,
  SiteProjects
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/site/SiteSections.jsx", error: String((e && e.message) || e) }); }

// ui_kits/site/site-data.js
try { (() => {
window.SITE = {
  name: "matheus alves",
  fullName: "Matheus Alves Cruz da Silva",
  role: "desenvolvedor front-end · designer de interfaces",
  location: "são paulo, brasil",
  intro: "Construo interfaces que precisam aguentar produção: rápidas, acessíveis e desenhadas até o último detalhe. Trabalho nas duas pontas — o desenho e o código que o entrega.",
  about: ["Comecei pelo design e fui parar no código porque queria ver a interface se comportar do jeito que eu havia desenhado. Hoje faço as duas coisas no mesmo dia: decido a tipografia e depois implemento o componente.", "Meu interesse é o comportamento da luz sobre superfície escura — refração, cáustica, aresta iluminada — feito com transform e opacity, dentro do orçamento de performance."],
  stack: [{
    heading: "front-end",
    items: ["react", "typescript", "next.js", "vite", "css moderno"],
    lit: ["react", "typescript"]
  }, {
    heading: "movimento",
    items: ["gsap", "motion", "webgl", "svg filters"],
    lit: ["gsap"]
  }, {
    heading: "interface",
    items: ["figma", "design systems", "protótipos", "acessibilidade"],
    lit: ["design systems"]
  }, {
    heading: "plataforma",
    items: ["node", "postgres", "vitest", "playwright", "ci/cd"],
    lit: []
  }],
  projects: [{
    title: "painel de operações",
    year: "2025",
    summary: "Dashboard em tempo real para logística. 40 mil linhas por sessão, virtualização e nenhum frame perdido.",
    stack: ["react", "typescript", "websocket"],
    image: "../../assets/imagery/curvas-metalicas.png"
  }, {
    title: "editor de campanhas",
    year: "2024",
    summary: "Editor drag-and-drop com histórico infinito e pré-visualização instantânea de artes.",
    stack: ["next.js", "zustand", "canvas"],
    image: "../../assets/imagery/formas-liquidas.png"
  }, {
    title: "identidade em movimento",
    year: "2024",
    summary: "Sistema de marca animada para estúdio de arquitetura: refração, cáustica e um só peso tipográfico.",
    stack: ["gsap", "webgl", "svg"],
    image: "../../assets/imagery/vidro-refracao.png"
  }, {
    title: "biblioteca de componentes",
    year: "2023",
    summary: "Design system interno com 48 componentes, documentação viva e testes visuais no CI.",
    stack: ["react", "storybook", "playwright"],
    image: "../../assets/imagery/luz-e-estrutura.png"
  }],
  experience: [{
    period: "2023 — agora",
    role: "desenvolvedor front-end",
    org: "produto interno",
    description: "Responsável pela camada de interface: design system, performance e acessibilidade. LCP médio de 4,3s para 1,8s em seis meses.",
    stack: ["react", "typescript", "gsap"],
    current: true
  }, {
    period: "2021 — 2023",
    role: "designer de interfaces",
    org: "agência",
    description: "Desenho e prototipagem de produtos digitais para clientes de varejo e educação. Entrega em Figma com handoff implementado por mim.",
    stack: ["figma", "next.js"]
  }, {
    period: "2019 — 2021",
    role: "front-end júnior",
    org: "consultoria",
    description: "Manutenção e reescrita de front-ends legados; primeira biblioteca de componentes compartilhada entre três squads.",
    stack: ["javascript", "sass"]
  }],
  credentials: [{
    title: "análise e desenvolvimento de sistemas",
    org: "instituição de ensino",
    year: "2024"
  }, {
    title: "acessibilidade web — WCAG 2.2",
    org: "certificado",
    year: "2024",
    href: "#"
  }, {
    title: "animação para interfaces",
    org: "certificado",
    year: "2023",
    href: "#"
  }, {
    title: "arquitetura front-end em escala",
    org: "certificado",
    year: "2022",
    href: "#"
  }],
  contacts: [{
    network: "github",
    label: "github",
    handle: "/macds",
    href: "https://github.com/"
  }, {
    network: "linkedin",
    label: "linkedin",
    handle: "/in/macds",
    href: "https://linkedin.com/"
  }, {
    network: "behance",
    label: "behance",
    handle: "/macds",
    href: "https://behance.net/"
  }, {
    network: "gmail",
    label: "e-mail",
    handle: "macds@email.com",
    href: "mailto:macds@email.com"
  }],
  sections: [{
    id: "sobre",
    label: "sobre"
  }, {
    id: "stack",
    label: "stack"
  }, {
    id: "projetos",
    label: "projetos"
  }, {
    id: "experiencia",
    label: "experiência"
  }, {
    id: "formacao",
    label: "formação"
  }, {
    id: "contato",
    label: "contato"
  }]
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/site/site-data.js", error: String((e && e.message) || e) }); }

__ds_ns.CredentialItem = __ds_scope.CredentialItem;

__ds_ns.SectionHeader = __ds_scope.SectionHeader;

__ds_ns.SocialLink = __ds_scope.SocialLink;

__ds_ns.StackGroup = __ds_scope.StackGroup;

__ds_ns.TimelineItem = __ds_scope.TimelineItem;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Divider = __ds_scope.Divider;

__ds_ns.Eyebrow = __ds_scope.Eyebrow;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.ThemeToggle = __ds_scope.ThemeToggle;

__ds_ns.Wordmark = __ds_scope.Wordmark;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.CausticBackdrop = __ds_scope.CausticBackdrop;

__ds_ns.Magnetic = __ds_scope.Magnetic;

__ds_ns.Marquee = __ds_scope.Marquee;

__ds_ns.Parallax = __ds_scope.Parallax;

__ds_ns.RefractionSurface = __ds_scope.RefractionSurface;

__ds_ns.ScrollMask = __ds_scope.ScrollMask;

__ds_ns.ScrollProgress = __ds_scope.ScrollProgress;

__ds_ns.Shatter = __ds_scope.Shatter;

__ds_ns.Fragment = __ds_scope.Fragment;

__ds_ns.SweepText = __ds_scope.SweepText;

__ds_ns.GlassPanel = __ds_scope.GlassPanel;

__ds_ns.Grain = __ds_scope.Grain;

__ds_ns.ProjectCard = __ds_scope.ProjectCard;

})();
