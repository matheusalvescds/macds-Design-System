const NS = window.MacdsDesignSystem_3cef76 || {};
/* Tolerant lookup, declared per file: the compiled bundle can trail the sources by a
   revision, and each file is also evaluated standalone by the compiler. */
const pick = (...names) => { for (const n of names) { if (NS[n]) return NS[n]; } return ({ children }) => children ?? null; };
const Wordmark = pick("Wordmark"), Eyebrow = pick("Eyebrow"), Grain = pick("Grain"), Tag = pick("Tag"), Icon = pick("Icon"), Divider = pick("Divider");

/* Artboard — a real-pixel canvas (1080×1350, 1080×1080, 1584×396) scaled to fit the
   viewport. Body type never below 28px at 1080 width. */
function Artboard({ w, h, children, scale, theme }) {
  return (
    <div style={{ width: w * scale, height: h * scale, flex: "0 0 auto" }}>
      <div data-theme={theme === "light" ? "light" : undefined} style={{
        width: w, height: h, transform: `scale(${scale})`, transformOrigin: "top left",
        position: "relative", overflow: "hidden", background: "var(--canvas)",
        border: "var(--border-hairline)",
      }}>
        {children}
        <Grain local opacity={0.05} />
      </div>
    </div>
  );
}

const plate = (n) => `../../assets/imagery/${n}.png`;

const SLIDES = [
  { kind: "capa", eyebrow: "carrossel · 01", title: "por que seu\nfront-end está\nlento", body: "Cinco causas que aparecem em quase todo projeto que eu recebo para consertar.", plate: "formas-liquidas" },
  { kind: "conteudo", eyebrow: "01", title: "imagem sem\nlazy-load", body: "Cada imagem acima da dobra disputa banda com o que o usuário precisa ler primeiro. Carregue depois o que está fora da tela.", metric: "−1,4s de LCP" },
  { kind: "conteudo", eyebrow: "02", title: "animação em\npropriedade\nerrada", body: "Animar width, top ou box-shadow força layout a cada frame. Só transform e opacity chegam a 60fps com folga.", metric: "60fps estáveis" },
  { kind: "conteudo", eyebrow: "03", title: "webgl antes\ndo primeiro\npaint", body: "Shader é segunda camada. Ele entra depois que o texto já está legível na tela — nunca bloqueando o render.", metric: "sem pré-loader" },
  { kind: "fecho", eyebrow: "carrossel · 05", title: "quer o\nchecklist\ncompleto?", body: "Comente “perf” e eu te mando. Trabalho com interface e performance no mesmo commit.", plate: "vidro-refracao" },
];

function CarouselSlide({ s, index, total, scale, theme }) {
  const cover = s.kind !== "conteudo";
  return (
    <Artboard w={1080} h={1350} scale={scale} theme={theme}>
      {cover && <>
        <img className="macds-plate" src={plate(s.plate)} alt="" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", opacity: 0.62 }} />
        <div style={{ position: "absolute", inset: 0, background: "var(--silence-veil-bottom)" }} />
      </>}
      <div style={{ position: "absolute", inset: 0, padding: 88, display: "grid", gridTemplateRows: "auto 1fr auto", gap: 40 }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <Wordmark size={44} />
          <span style={{ fontFamily: "var(--font-mono)", fontSize: 28, letterSpacing: "0.14em", textTransform: "uppercase", color: "var(--text-secondary)" }}>{s.eyebrow}</span>
        </div>
        <div style={{ alignSelf: cover ? "end" : "center", display: "grid", gap: 40 }}>
          <h2 style={{ margin: 0, fontFamily: "var(--font-display)", fontWeight: 700, fontSize: cover ? 132 : 108, lineHeight: 0.92, letterSpacing: "-0.05em", color: "var(--text-primary)", whiteSpace: "pre-line" }}>{s.title}</h2>
          <p style={{ margin: 0, fontSize: 34, lineHeight: 1.5, color: "var(--text-secondary)", maxWidth: "26ch" }}>{s.body}</p>
          {s.metric && <span style={{ justifySelf: "start", fontFamily: "var(--font-mono)", fontSize: 30, padding: "16px 26px", border: "1px solid var(--border-lit)", borderRadius: 8, color: "var(--text-primary)", background: "var(--surface-2)", boxShadow: "var(--edge-top)" }}>{s.metric}</span>}
        </div>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", borderTop: "var(--border-hairline)", paddingTop: 32 }}>
          <span style={{ fontFamily: "var(--font-mono)", fontSize: 28, color: "var(--text-tertiary)" }}>matheus alves · front-end</span>
          <span style={{ fontFamily: "var(--font-mono)", fontSize: 28, color: "var(--text-secondary)" }}>{String(index + 1).padStart(2, "0")}/{String(total).padStart(2, "0")}</span>
        </div>
      </div>
    </Artboard>
  );
}

function PostSquare({ scale, theme }) {
  return (
    <Artboard w={1080} h={1080} scale={scale} theme={theme}>
      <img className="macds-plate" src={plate("curvas-metalicas")} alt="" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", opacity: 0.7 }} />
      <div style={{ position: "absolute", inset: 0, background: "var(--silence-veil)" }} />
      <div style={{ position: "absolute", inset: 0, padding: 88, display: "grid", gridTemplateRows: "auto 1fr auto", gap: 32 }}>
        <Wordmark size={44} />
        <div style={{ alignSelf: "center", display: "grid", gap: 36, maxWidth: 620 }}>
          <span style={{ fontFamily: "var(--font-mono)", fontSize: 28, letterSpacing: "0.14em", textTransform: "uppercase", color: "var(--text-secondary)" }}>post · nota técnica</span>
          <h2 style={{ margin: 0, fontFamily: "var(--font-display)", fontWeight: 700, fontSize: 116, lineHeight: 0.92, letterSpacing: "-0.05em", color: "var(--text-primary)" }}>luz não é<br />cor</h2>
          <p style={{ margin: 0, fontSize: 34, lineHeight: 1.5, color: "var(--text-secondary)" }}>Num sistema monocromático o branco puro é reservado para aresta, halo e fio de luz. Texto vive em #F2F2F4.</p>
        </div>
        <span style={{ fontFamily: "var(--font-mono)", fontSize: 28, color: "var(--text-tertiary)" }}>macds · design system pessoal</span>
      </div>
    </Artboard>
  );
}

function BannerWide({ scale, theme }) {
  return (
    <Artboard w={1584} h={396} scale={scale} theme={theme}>
      <img className="macds-plate" src={plate("luz-e-estrutura")} alt="" style={{ position: "absolute", right: 0, top: 0, height: "100%", width: "52%", objectFit: "cover", opacity: 0.72 }} />
      <div style={{ position: "absolute", inset: 0, background: "var(--silence-veil)" }} />
      <div style={{ position: "absolute", inset: 0, padding: "56px 72px", display: "grid", alignContent: "center", gap: 20, maxWidth: 900 }}>
        <h2 style={{ margin: 0, fontFamily: "var(--font-display)", fontWeight: 700, fontSize: 84, lineHeight: 0.94, letterSpacing: "-0.05em", color: "var(--text-primary)" }}>matheus alves</h2>
        <p style={{ margin: 0, fontFamily: "var(--font-mono)", fontSize: 30, color: "var(--text-secondary)" }}>desenvolvedor front-end · designer de interfaces</p>
      </div>
    </Artboard>
  );
}

function LinkedinApp() {
  const [piece, setPiece] = React.useState("carrossel");
  const [theme, setTheme] = React.useState("dark");
  const [i, setI] = React.useState(0);
  const scale = piece === "banner" ? 0.42 : 0.3;
  return (
    <div style={{ minHeight: "100vh", padding: "32px var(--gutter) 64px", display: "grid", gap: 32, justifyItems: "center", alignContent: "start" }}>
      <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap", justifyContent: "center" }}>
        {[["carrossel", "carrossel 1080×1350"], ["post", "post 1080×1080"], ["banner", "banner 1584×396"]].map(([k, l]) => (
          <button key={k} onClick={() => setPiece(k)} aria-pressed={piece === k} style={{ background: "none", border: 0, padding: 0, cursor: "pointer" }}>
            <Tag lit={piece === k}>{l}</Tag>
          </button>
        ))}
        <span aria-hidden="true" style={{ width: 1, height: 22, background: "var(--border)", margin: "0 6px" }} />
        {[["dark", "escuro"], ["light", "claro"]].map(([k, l]) => (
          <button key={k} onClick={() => setTheme(k)} aria-pressed={theme === k} style={{ background: "none", border: 0, padding: 0, cursor: "pointer" }}>
            <Tag lit={theme === k}>{l}</Tag>
          </button>
        ))}
      </div>
      {piece === "carrossel" && <>
        <CarouselSlide s={SLIDES[i]} index={i} total={SLIDES.length} scale={scale} theme={theme} />
        <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
          <button onClick={() => setI((v) => Math.max(0, v - 1))} disabled={i === 0} aria-label="slide anterior" style={btn}><Icon name="arrow-left" size={18} /></button>
          <span style={{ fontFamily: "var(--font-mono)", fontSize: "var(--text-xs)", color: "var(--text-secondary)", minWidth: 56, textAlign: "center" }}>{i + 1} / {SLIDES.length}</span>
          <button onClick={() => setI((v) => Math.min(SLIDES.length - 1, v + 1))} disabled={i === SLIDES.length - 1} aria-label="próximo slide" style={btn}><Icon name="arrow-right" size={18} /></button>
        </div>
      </>}
      {piece === "post" && <PostSquare scale={scale} theme={theme} />}
      {piece === "banner" && <BannerWide scale={scale} theme={theme} />}
    </div>
  );
}
const btn = { width: 44, height: 44, display: "grid", placeItems: "center", background: "transparent", border: "var(--border-hairline)", borderRadius: "var(--radius-md)", color: "var(--icon)", cursor: "pointer" };

const liRoot = document.getElementById("root");
if (liRoot) ReactDOM.createRoot(liRoot).render(<LinkedinApp />);
