# UI kit — peças de LinkedIn

Extensão secundária do sistema, em pixel real, escalada para caber na tela.

- Carrossel **1080×1350** (5 slides: capa, três de conteúdo, fecho) com navegação.
- Post **1080×1080**.
- Banner de perfil **1584×396**.

Regras aplicadas: corpo nunca abaixo de 28px na arte de 1080; zona de silêncio sólida sob todo texto; plate de imagem sempre em grayscale; wordmark presente em toda peça; grão a 5% (levemente acima do site, para sobreviver à recompressão do LinkedIn).

Alternância escuro/claro por peça: o `Artboard` recebe `theme`, que aplica `[data-theme="light"]` no canvas em pixel real; os plates carregam `class="macds-plate"` para inverterem junto e continuarem legíveis em papel.

`LinkedinPieces.jsx` contém o componente `Artboard` (canvas em pixel real + escala) e as três peças.
