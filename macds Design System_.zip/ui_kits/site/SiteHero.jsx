const NS = window.MacdsDesignSystem_3cef76 || {};
/* Tolerant lookup, declared per file: the compiled bundle can trail the sources by a
   revision, and each file is also evaluated standalone by the compiler. */
const pick = (...names) => { for (const n of names) { if (NS[n]) return NS[n]; } return ({ children }) => children ?? null; };
const Wordmark = pick("Wordmark"), Button = pick("Button"), Icon = pick("Icon"), Magnetic = pick("Magnetic"), CausticBackdrop = pick("CausticBackdrop"), Eyebrow = pick("Eyebrow"), ThemeToggle = pick("ThemeToggle"), Parallax = pick("Parallax"), Marquee = pick("Marquee");

/* Fixed hairline nav. Lowercase links, mono, no background until scrolled. */
function SiteNav({ active }) {
  const [lit, setLit] = React.useState(false);
  React.useEffect(() => {
    const onScroll = () => setLit(window.scrollY > 40);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return (
    <header style={{
      position: "fixed", top: 0, left: 0, right: 0, zIndex: 50,
      display: "flex", alignItems: "center", justifyContent: "space-between",
      padding: "var(--sp-4) var(--gutter)",
      background: lit ? "var(--surface-glass)" : "transparent",
      backdropFilter: lit ? "blur(14px) saturate(0)" : "none",
      borderBottom: lit ? "var(--border-hairline)" : "1px solid transparent",
      transition: "background var(--dur-base) var(--ease), border-color var(--dur-base) var(--ease)",
    }}>
      <a href="#top" style={{ lineHeight: 0 }}><Wordmark size={26} /></a>
      <div style={{ display: "flex", alignItems: "center", gap: "var(--sp-5)" }}>
        <nav aria-label="seções" style={{ display: "flex", gap: "var(--sp-5)", alignItems: "center" }}>
          {window.SITE.sections.map((s) => (
            <a key={s.id} href={`#${s.id}`} style={{
              fontFamily: "var(--font-mono)", fontSize: "var(--text-label)", textTransform: "uppercase",
              letterSpacing: "var(--tracking-label)", color: active === s.id ? "var(--text-primary)" : "var(--text-secondary)",
              padding: "10px 0", transition: "color var(--dur-base) var(--ease)",
            }} className="site-nav-link">{s.label}</a>
          ))}
        </nav>
        <ThemeToggle />
      </div>
    </header>
  );
}

/* Hero — name, role, dual CTA on a solid zona de silêncio at the left; the light portrait
   occupies the right half with scroll-linked parallax over the animated caustic field.
   Text is present without waiting for animation. */
function SiteHero() {
  return (
    <section id="top" style={{ position: "relative", minHeight: "100svh", display: "grid", alignContent: "center", overflow: "hidden", paddingTop: "calc(var(--sp-8) + var(--sp-6))", paddingBottom: "var(--sp-10)" }}>
      <CausticBackdrop plate="../../assets/imagery/formas-liquidas.png" intensity={0.55} />
      <Parallax distance={110} scale={0.06} as="figure" className="site-hero-portrait" style={{ position: "absolute", top: 0, right: 0, bottom: 0, width: "58%", margin: 0, zIndex: 0 }}>
        <img className="macds-plate" src="../../assets/imagery/retrato-luz.png" alt="" loading="eager" fetchpriority="high"
          style={{ width: "100%", height: "112%", objectFit: "cover", objectPosition: "50% 18%" }} />
        <span aria-hidden="true" style={{ position: "absolute", inset: 0, background: "var(--silence-veil)" }} />
      </Parallax>
      <div style={{ position: "relative", zIndex: 1, padding: "0 var(--gutter)", maxWidth: "var(--container)", margin: "0 auto", width: "100%" }}>
        <div className="macds-silence" style={{ display: "grid", gap: "var(--sp-6)", maxWidth: "22ch" }}>
          <Eyebrow>{window.SITE.location}</Eyebrow>
          <h1 className="macds-hero" style={{ margin: 0 }}>matheus<br />alves</h1>
          <p style={{ margin: 0, fontFamily: "var(--font-mono)", fontSize: "var(--text-sm)", color: "var(--text-secondary)", letterSpacing: 0 }}>{window.SITE.role}</p>
          <div style={{ display: "flex", gap: "var(--sp-3)", flexWrap: "wrap", marginTop: "var(--sp-3)" }}>
            <Magnetic pull={10}><Button variant="light" size="lg" href="#projetos" iconAfter={<Icon name="arrow-down-right" size={16} />}>ver projetos</Button></Magnetic>
            <Button variant="ghost" size="lg" href="#contato" iconAfter={<Icon name="download" size={16} />}>baixar CV</Button>
          </div>
        </div>
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, zIndex: 1, borderTop: "var(--border-hairline)", padding: "var(--sp-4) 0", background: "linear-gradient(0deg,var(--canvas),transparent)" }}>
        <Marquee items={["react", "typescript", "gsap", "webgl", "design systems", "acessibilidade", "performance"]} speed={48} />
      </div>
    </section>
  );
}

Object.assign(window, { SiteNav, SiteHero });
