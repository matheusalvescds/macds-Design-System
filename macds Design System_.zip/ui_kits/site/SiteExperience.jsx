const NS = window.MacdsDesignSystem_3cef76 || {};
/* Tolerant lookup, declared per file: the compiled bundle can trail the sources by a
   revision, and each file is also evaluated standalone by the compiler. */
const pick = (...names) => { for (const n of names) { if (NS[n]) return NS[n]; } return ({ children }) => children ?? null; };
const SectionHeader = pick("SectionHeader"), TimelineItem = pick("TimelineItem"), CredentialItem = pick("CredentialItem"), SocialLink = pick("SocialLink"), Input = pick("Input"), Button = pick("Button"), Wordmark = pick("Wordmark"), Divider = pick("Divider"), Icon = pick("Icon"), Eyebrow = pick("Eyebrow"), Magnetic = pick("Magnetic"), ScrollMask = pick("ScrollMask"), Shatter = pick("Shatter", "Fragment");

function SiteTimeline() {
  return (
    <window.Section id="experiencia">
      <ScrollMask><SectionHeader index="04" label="experiência" title="sete anos entre desenho e código" /></ScrollMask>
      <ul style={{ margin: 0, padding: 0 }}>
        {window.SITE.experience.map((e) => <TimelineItem key={e.period} {...e} />)}
      </ul>
    </window.Section>
  );
}

function SiteCredentials() {
  return (
    <window.Section id="formacao">
      <ScrollMask><SectionHeader index="05" label="formação e certificados" title="onde aprendi o que uso" /></ScrollMask>
      <div>
        {window.SITE.credentials.map((c) => <CredentialItem key={c.title} {...c} />)}
      </div>
    </window.Section>
  );
}

function SiteContact() {
  const [sent, setSent] = React.useState(false);
  return (
    <window.Section id="contato">
      <div style={{ display: "grid", gridTemplateColumns: "minmax(0,1fr) minmax(0,1fr)", gap: "var(--sp-9)" }} className="site-two-col">
        <div>
          <SectionHeader index="06" label="contato" title="disponível para conversar" lead="Respondo em até dois dias úteis." />
          <div>
            {window.SITE.contacts.map((c) => <SocialLink key={c.label} {...c} />)}
          </div>
        </div>
        <form onSubmit={(e) => { e.preventDefault(); setSent(true); }} style={{ display: "grid", gap: "var(--sp-6)", alignContent: "start", paddingTop: "var(--sp-8)" }}>
          <Input label="nome" placeholder="como te chamo" required />
          <Input label="e-mail" type="email" placeholder="voce@empresa.com" required />
          <Input label="mensagem" textarea rows={4} placeholder="o que você precisa construir" />
          <div style={{ display: "flex", alignItems: "center", gap: "var(--sp-5)" }}>
            <Magnetic pull={8}><Button variant="light" type="submit" iconAfter={<Icon name="arrow-up-right" size={16} />}>enviar mensagem</Button></Magnetic>
            {sent && <span style={{ fontFamily: "var(--font-mono)", fontSize: "var(--text-xs)", color: "var(--text-secondary)" }}>mensagem registrada · protótipo</span>}
          </div>
        </form>
      </div>
    </window.Section>
  );
}

function SiteFooter() {
  return (
    <footer style={{ padding: "var(--sp-8) var(--gutter) var(--sp-7)", maxWidth: "var(--container)", margin: "0 auto" }}>
      <Divider filament />
      <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", gap: "var(--sp-6)", paddingTop: "var(--sp-7)", flexWrap: "wrap" }}>
        <Shatter shards={6} spread={70}><Wordmark size={64} /></Shatter>
        <div style={{ display: "grid", gap: "var(--sp-2)", textAlign: "right" }}>
          <span style={{ fontFamily: "var(--font-mono)", fontSize: "var(--text-xs)", color: "var(--text-secondary)" }}>{window.SITE.fullName}</span>
          <span style={{ fontFamily: "var(--font-mono)", fontSize: "var(--text-xs)", color: "var(--text-tertiary)" }}>{window.SITE.location} · 2026</span>
        </div>
      </div>
    </footer>
  );
}

Object.assign(window, { SiteTimeline, SiteCredentials, SiteContact, SiteFooter });
