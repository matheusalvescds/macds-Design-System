const NS = window.MacdsDesignSystem_3cef76 || {};
/* Tolerant lookup, declared per file: the compiled bundle can trail the sources by a
   revision, and each file is also evaluated standalone by the compiler. */
const pick = (...names) => { for (const n of names) { if (NS[n]) return NS[n]; } return ({ children }) => children ?? null; };
const Grain = pick("Grain"), ScrollProgress = pick("ScrollProgress");

/* Light source bound to scroll: one fixed luminance layer whose position rotates as the
   page moves. Transform/background-position only, and frozen under reduced motion. */
function ScrollLight() {
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    let raf = 0;
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const p = window.scrollY / Math.max(1, document.body.scrollHeight - window.innerHeight);
        const a = p * Math.PI * 2;
        if (ref.current) ref.current.style.transform = `translate3d(${Math.cos(a) * 12}%,${Math.sin(a) * 14}%,0)`;
      });
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => { window.removeEventListener("scroll", onScroll); cancelAnimationFrame(raf); };
  }, []);
  return <div ref={ref} aria-hidden="true" style={{
    position: "fixed", inset: "-25%", zIndex: 0, pointerEvents: "none", willChange: "transform",
    background: "radial-gradient(42% 34% at 62% 38%, rgba(255,255,255,.055), transparent 68%)",
  }} />;
}

function SiteApp() {
  const [active, setActive] = React.useState("sobre");
  React.useEffect(() => {
    const ids = window.SITE.sections.map((s) => s.id);
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => { if (e.isIntersecting) setActive(e.target.id); });
    }, { rootMargin: "-45% 0px -50% 0px" });
    ids.forEach((id) => { const el = document.getElementById(id); if (el) io.observe(el); });
    return () => io.disconnect();
  }, []);
  return (
    <>
      <ScrollProgress />
      <ScrollLight />
      <window.SiteNav active={active} />
      <main style={{ position: "relative", zIndex: 1 }}>
        <window.SiteHero />
        <window.SiteAbout />
        <window.SiteStack />
        <window.SiteProjects />
        <window.SiteTimeline />
        <window.SiteCredentials />
        <window.SiteContact />
      </main>
      <window.SiteFooter />
      <Grain />
    </>
  );
}

const siteRoot = document.getElementById("root");
if (siteRoot) ReactDOM.createRoot(siteRoot).render(<SiteApp />);
