window.SITE = {
  name: "matheus alves",
  fullName: "Matheus Alves Cruz da Silva",
  role: "desenvolvedor front-end · designer de interfaces",
  location: "são paulo, brasil",
  intro: "Construo interfaces que precisam aguentar produção: rápidas, acessíveis e desenhadas até o último detalhe. Trabalho nas duas pontas — o desenho e o código que o entrega.",
  about: [
    "Comecei pelo design e fui parar no código porque queria ver a interface se comportar do jeito que eu havia desenhado. Hoje faço as duas coisas no mesmo dia: decido a tipografia e depois implemento o componente.",
    "Meu interesse é o comportamento da luz sobre superfície escura — refração, cáustica, aresta iluminada — feito com transform e opacity, dentro do orçamento de performance."
  ],
  stack: [
    { heading: "front-end", items: ["react", "typescript", "next.js", "vite", "css moderno"], lit: ["react", "typescript"] },
    { heading: "movimento", items: ["gsap", "motion", "webgl", "svg filters"], lit: ["gsap"] },
    { heading: "interface", items: ["figma", "design systems", "protótipos", "acessibilidade"], lit: ["design systems"] },
    { heading: "plataforma", items: ["node", "postgres", "vitest", "playwright", "ci/cd"], lit: [] }
  ],
  projects: [
    { title: "painel de operações", year: "2025", summary: "Dashboard em tempo real para logística. 40 mil linhas por sessão, virtualização e nenhum frame perdido.", stack: ["react", "typescript", "websocket"], image: "../../assets/imagery/curvas-metalicas.png" },
    { title: "editor de campanhas", year: "2024", summary: "Editor drag-and-drop com histórico infinito e pré-visualização instantânea de artes.", stack: ["next.js", "zustand", "canvas"], image: "../../assets/imagery/formas-liquidas.png" },
    { title: "identidade em movimento", year: "2024", summary: "Sistema de marca animada para estúdio de arquitetura: refração, cáustica e um só peso tipográfico.", stack: ["gsap", "webgl", "svg"], image: "../../assets/imagery/vidro-refracao.png" },
    { title: "biblioteca de componentes", year: "2023", summary: "Design system interno com 48 componentes, documentação viva e testes visuais no CI.", stack: ["react", "storybook", "playwright"], image: "../../assets/imagery/luz-e-estrutura.png" }
  ],
  experience: [
    { period: "2023 — agora", role: "desenvolvedor front-end", org: "produto interno", description: "Responsável pela camada de interface: design system, performance e acessibilidade. LCP médio de 4,3s para 1,8s em seis meses.", stack: ["react", "typescript", "gsap"], current: true },
    { period: "2021 — 2023", role: "designer de interfaces", org: "agência", description: "Desenho e prototipagem de produtos digitais para clientes de varejo e educação. Entrega em Figma com handoff implementado por mim.", stack: ["figma", "next.js"] },
    { period: "2019 — 2021", role: "front-end júnior", org: "consultoria", description: "Manutenção e reescrita de front-ends legados; primeira biblioteca de componentes compartilhada entre três squads.", stack: ["javascript", "sass"] }
  ],
  credentials: [
    { title: "análise e desenvolvimento de sistemas", org: "instituição de ensino", year: "2024" },
    { title: "acessibilidade web — WCAG 2.2", org: "certificado", year: "2024", href: "#" },
    { title: "animação para interfaces", org: "certificado", year: "2023", href: "#" },
    { title: "arquitetura front-end em escala", org: "certificado", year: "2022", href: "#" }
  ],
  contacts: [
    { network: "github", label: "github", handle: "/macds", href: "https://github.com/" },
    { network: "linkedin", label: "linkedin", handle: "/in/macds", href: "https://linkedin.com/" },
    { network: "behance", label: "behance", handle: "/macds", href: "https://behance.net/" },
    { network: "gmail", label: "e-mail", handle: "macds@email.com", href: "mailto:macds@email.com" }
  ],
  sections: [
    { id: "sobre", label: "sobre" },
    { id: "stack", label: "stack" },
    { id: "projetos", label: "projetos" },
    { id: "experiencia", label: "experiência" },
    { id: "formacao", label: "formação" },
    { id: "contato", label: "contato" }
  ]
};
