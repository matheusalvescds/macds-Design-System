const NS = window.MacdsDesignSystem_3cef76 || {};
/* Tolerant lookup, declared per file: the compiled bundle can trail the sources by a
   revision, and each file is also evaluated standalone by the compiler. */
const pick = (...names) => { for (const n of names) { if (NS[n]) return NS[n]; } return ({ children }) => children ?? null; };
const SectionHeader = pick("SectionHeader"), StackGroup = pick("StackGroup"), Divider = pick("Divider"), ProjectCard = pick("ProjectCard"), Tag = pick("Tag"), Eyebrow = pick("Eyebrow"), ScrollMask = pick("ScrollMask");

function Section({ id, children, style }) {
  return (
    <section id={id} style={{ padding: "var(--section-y) var(--gutter)", maxWidth: "var(--container)", margin: "0 auto", ...style }}>
      {children}
    </section>
  );
}

function SiteAbout() {
  return (
    <Section id="sobre">
      <div style={{ display: "grid", gridTemplateColumns: "minmax(0,1fr) minmax(0,1.1fr)", gap: "var(--sp-9)", alignItems: "start" }} className="site-two-col">
        <ScrollMask><SectionHeader index="01" label="sobre" title="desenho e implemento a mesma interface" style={{ marginBottom: 0 }} /></ScrollMask>
        <div style={{ display: "grid", gap: "var(--sp-5)" }}>
          {window.SITE.about.map((p, i) => (
            <p key={i} style={{ margin: 0, fontSize: i === 0 ? "var(--text-lg)" : "var(--text-md)", lineHeight: i === 0 ? "var(--leading-snug)" : "var(--leading-body)", color: i === 0 ? "var(--text-primary)" : "var(--text-secondary)", maxWidth: "var(--measure)" }}>{p}</p>
          ))}
        </div>
      </div>
    </Section>
  );
}

function SiteStack() {
  return (
    <Section id="stack">
      <ScrollMask><SectionHeader index="02" label="stack e competências" title="ferramentas que uso todos os dias" /></ScrollMask>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(220px,1fr))", gap: "var(--sp-7)" }}>
        {window.SITE.stack.map((g) => <StackGroup key={g.heading} heading={g.heading} items={g.items} lit={g.lit} />)}
      </div>
    </Section>
  );
}

function SiteProjects() {
  const [filter, setFilter] = React.useState("todos");
  const all = window.SITE.projects;
  const tags = ["todos", ...new Set(all.flatMap((p) => p.stack))].slice(0, 7);
  const shown = filter === "todos" ? all : all.filter((p) => p.stack.includes(filter));
  return (
    <Section id="projetos">
      <ScrollMask><SectionHeader index="03" label="projetos" title="quatro peças que aguentaram produção" lead="Filtre por tecnologia." /></ScrollMask>
      <div style={{ display: "flex", gap: "var(--sp-2)", flexWrap: "wrap", marginBottom: "var(--sp-7)" }}>
        {tags.map((t) => (
          <button key={t} onClick={() => setFilter(t)} style={{ background: "none", border: 0, padding: 0, cursor: "pointer" }} aria-pressed={filter === t}>
            <Tag lit={filter === t}>{t}</Tag>
          </button>
        ))}
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(320px,1fr))", gap: "var(--sp-6)" }}>
        {shown.map((p) => <ProjectCard key={p.title} {...p} />)}
      </div>
    </Section>
  );
}

Object.assign(window, { Section, SiteAbout, SiteStack, SiteProjects });
