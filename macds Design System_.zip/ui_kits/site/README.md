# UI kit — site-currículo

Recreação interativa do artefato principal: página única, ordem de seções exigida pelo briefing — hero (nome, cargo, CTA duplo) · sobre · stack e competências · projetos · experiência em timeline · formação e certificados · contato · rodapé.

- `index.html` — monta o app; carrega `styles.css`, o bundle do design system e os arquivos JSX.
- `site-data.js` — todo o conteúdo (`window.SITE`). Conteúdo plausível, porém fictício.
- `SiteHero.jsx` — nav fixa com scroll-spy + hero com cáustica animada, light sweep e CTA duplo.
- `SiteSections.jsx` — sobre, stack, projetos (filtro por tecnologia, cards com refração).
- `SiteExperience.jsx` — timeline, formação, contato (formulário + links) e rodapé.
- `SiteApp.jsx` — fonte de luz atrelada ao scroll, scroll-spy, grão.

Interações reais: navegação por âncora com scroll-spy, filtro de projetos, refração no hover dos cards, cursor magnético nos CTAs, formulário de contato com confirmação simulada. Tudo em `transform`/`opacity`; refração e cáustica congelam abaixo de 768px e sob `prefers-reduced-motion`.
