import React from "react";

/* macds Eyebrow — mono uppercase label with wide tracking. Optional index numeral,
   the system's section counter ("01 / sobre"). */
export function Eyebrow({ index, children, style, ...rest }) {
  return (
    <p style={{ display: "flex", alignItems: "center", gap: "var(--sp-3)", margin: 0,
      fontFamily: "var(--font-mono)", fontSize: "var(--text-label)", textTransform: "uppercase",
      letterSpacing: "var(--tracking-label)", color: "var(--text-secondary)", ...style }} {...rest}>
      {index && <span style={{ color: "var(--text-tertiary)" }}>{index}</span>}
      {index && <span aria-hidden="true" style={{ width: 28, height: 1, background: "var(--border-strong)" }} />}
      {children}
    </p>
  );
}
