import React from "react";

/* macds Icon — inlines an SVG from a CDN icon set so it inherits currentColor.
   `set="lucide"` for UI glyphs (1.5px stroke, no fill), `set="simple"` for brand marks
   (GitHub, LinkedIn, Behance). No icon binaries shipped with the brief — see readme
   ICONOGRAPHY for the substitution note. */
const SRC = {
  lucide: (n) => `https://cdn.jsdelivr.net/npm/lucide-static@0.428.0/icons/${n}.svg`,
  simple: (n) => `https://cdn.jsdelivr.net/npm/simple-icons@13.0.0/icons/${n}.svg`,
};
const cache = new Map();

export function Icon({ name, set = "lucide", size = 20, strokeWidth = 1.5, style, ...rest }) {
  const [svg, setSvg] = React.useState(() => cache.get(set + name) || "");
  React.useEffect(() => {
    const key = set + name;
    if (cache.has(key)) { setSvg(cache.get(key)); return; }
    let alive = true;
    fetch(SRC[set](name)).then((r) => (r.ok ? r.text() : "")).then((t) => {
      if (!t) return;
      const clean = t
        .replace(/<svg([^>]*)>/, (m, a) => `<svg${a.replace(/width="[^"]*"/, "").replace(/height="[^"]*"/, "")} width="100%" height="100%" fill="${set === "simple" ? "currentColor" : "none"}" stroke="${set === "simple" ? "none" : "currentColor"}" stroke-width="${strokeWidth}">`)
        .replace(/<title>.*?<\/title>/, "");
      cache.set(key, clean); if (alive) setSvg(clean);
    });
    return () => { alive = false; };
  }, [name, set, strokeWidth]);
  return <span aria-hidden="true" style={{ width: size, height: size, display: "inline-block", flex: "0 0 auto", color: "currentColor", ...style }} dangerouslySetInnerHTML={{ __html: svg }} {...rest} />;
}
