export interface EyebrowProps {
  /** zero-padded section counter, e.g. "02" */
  index?: string;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Eyebrow(props: EyebrowProps): JSX.Element;
