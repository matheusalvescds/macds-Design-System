export interface DividerProps {
  /** send a travelling pulse of pure light along the line */
  filament?: boolean;
  style?: React.CSSProperties;
}
export declare function Divider(props: DividerProps): JSX.Element;
