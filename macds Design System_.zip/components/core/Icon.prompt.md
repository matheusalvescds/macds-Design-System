Inlines a CDN icon so it inherits `currentColor` — the only icon path in the system.

```jsx
<Icon name="arrow-up-right" size={18} />
<Icon set="simple" name="behance" size={18} />
```

UI glyphs: Lucide, 1.5px stroke, 18–20px. Brand marks: Simple Icons, filled. Never emoji, never a hand-drawn SVG, never a colored brand logo — brand marks render in `--icon` or `--text-primary`.
