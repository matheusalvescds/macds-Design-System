export interface ThemeToggleProps {
  /** which node carries [data-theme] — the html element by default */
  target?: "documentElement" | "body";
  style?: React.CSSProperties;
}
export declare function ThemeToggle(props: ThemeToggleProps): JSX.Element;
