export interface IconButtonProps {
  /** required accessible name — icon-only controls carry no visible text */
  label: string;
  children?: React.ReactNode;
  href?: string;
  /** px; never below 44 for touch targets */
  size?: number;
  disabled?: boolean;
  style?: React.CSSProperties;
}
export declare function IconButton(props: IconButtonProps): JSX.Element;
