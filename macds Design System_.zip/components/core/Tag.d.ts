export interface TagProps {
  children?: React.ReactNode;
  /** lit = filled surface + light edge, for the current/primary item */
  lit?: boolean;
  style?: React.CSSProperties;
}
export declare function Tag(props: TagProps): JSX.Element;
