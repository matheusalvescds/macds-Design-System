export interface ButtonProps {
  /** `light` = lit plate (primary CTA), `ghost` = hairline outline. There is no colored variant. */
  variant?: "light" | "ghost";
  size?: "sm" | "md" | "lg";
  as?: "button" | "a" | "span";
  /** renders as an anchor when set */
  href?: string;
  icon?: React.ReactNode;
  iconAfter?: React.ReactNode;
  disabled?: boolean;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Button(props: ButtonProps): JSX.Element;
