Monochrome action control — `light` for the one primary CTA per view, `ghost` for everything else.

```jsx
<Button variant="light" size="lg" href="#projetos">ver projetos</Button>
<Button variant="ghost" size="lg" iconAfter={<Icon name="arrow-down" size={16} />}>baixar CV</Button>
```

Hover raises edge light / halo — never scale, never a color shift. Labels are lowercase, verb-first, Portuguese ("ver projetos", "baixar CV", "enviar mensagem"). Sizes: `sm` 36px, `md`/`lg` respect the 44px minimum target.
