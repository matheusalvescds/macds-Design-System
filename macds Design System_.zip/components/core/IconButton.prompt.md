Icon-only hairline square, used for social links and utility actions in headers/footers.

```jsx
<IconButton label="GitHub" href="https://github.com/macds"><Icon set="simple" name="github" size={18} /></IconButton>
```

Always pass `label` — there is no visible text. Default 44px meets the minimum target.
