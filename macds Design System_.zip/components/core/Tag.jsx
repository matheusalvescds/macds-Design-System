import React from "react";

/* macds Tag — hairline chip for stack items and project meta. Mono type, uppercase off. */
export function Tag({ children, lit = false, style, ...rest }) {
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", height: 30, padding: "0 12px",
      fontFamily: "var(--font-mono)", fontSize: "var(--text-xs)", letterSpacing: "0",
      color: lit ? "var(--text-primary)" : "var(--text-secondary)",
      background: lit ? "var(--surface-2)" : "transparent",
      border: `1px solid ${lit ? "var(--border-lit)" : "var(--border)"}`,
      borderRadius: "var(--radius-sm)", boxShadow: lit ? "var(--edge-top)" : "none", ...style,
    }} {...rest}>{children}</span>
  );
}
