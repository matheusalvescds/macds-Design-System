The brand mark: "macds" set in type, never an illustrated logo. Lowercase always.

```jsx
<Wordmark size={64} sweep as="h1" />
<Wordmark monogram size={32} />
```

There is no logo file in this system — the wordmark IS the type. Do not letterspace it positively, do not capitalize, do not add a symbol next to it.
