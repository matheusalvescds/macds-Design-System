Mono uppercase section label, optionally numbered — the only uppercase text in the system.

```jsx
<Eyebrow index="02">stack</Eyebrow>
```
