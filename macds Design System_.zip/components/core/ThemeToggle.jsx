import React from "react";
import { Icon } from "./Icon.jsx";

/* macds ThemeToggle — flips [data-theme] on <html> between the dark system (default) and
   the paper/light system, where pure black takes the role of light. Morphs the glyph
   instead of crossfading. */
export function ThemeToggle({ target = "documentElement", style, ...rest }) {
  const [theme, setTheme] = React.useState("dark");
  React.useEffect(() => {
    const root = target === "documentElement" ? document.documentElement : document.body;
    const saved = localStorage.getItem("macds-theme");
    if (saved) { setTheme(saved); if (saved === "light") root.setAttribute("data-theme", "light"); }
  }, [target]);
  const flip = () => {
    const root = target === "documentElement" ? document.documentElement : document.body;
    const next = theme === "dark" ? "light" : "dark";
    setTheme(next);
    if (next === "light") root.setAttribute("data-theme", "light"); else root.removeAttribute("data-theme");
    localStorage.setItem("macds-theme", next);
  };
  return (
    <button onClick={flip} aria-label={theme === "dark" ? "usar tema claro" : "usar tema escuro"}
      style={{ width: 44, height: 44, display: "inline-grid", placeItems: "center", background: "transparent",
        border: "var(--border-hairline)", borderRadius: "var(--radius-md)", color: "var(--icon)", cursor: "pointer",
        boxShadow: "var(--edge-top)", transition: "border-color var(--dur-base) var(--ease), color var(--dur-base) var(--ease)", ...style }}
      onMouseEnter={(e) => { e.currentTarget.style.borderColor = "var(--border-lit)"; e.currentTarget.style.color = "var(--text-primary)"; }}
      onMouseLeave={(e) => { e.currentTarget.style.borderColor = "var(--border)"; e.currentTarget.style.color = "var(--icon)"; }}
      {...rest}>
      <span style={{ display: "grid", placeItems: "center", transform: `rotate(${theme === "dark" ? 0 : 180}deg)`, transition: "transform var(--dur-mid) var(--ease)" }}>
        <Icon name={theme === "dark" ? "sun" : "moon"} size={18} />
      </span>
    </button>
  );
}
