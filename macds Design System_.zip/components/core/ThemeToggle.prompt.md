Switches between the dark system and the paper (light) system; remembers the choice in localStorage.

```jsx
<ThemeToggle />
```

The light theme is not a tint of the dark one: `tokens/theme-light.css` inverts the rule so pure **black** becomes the light — edges, filaments, halos. Plates need `class="macds-plate"` to invert with it.
