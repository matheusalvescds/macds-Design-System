import React from "react";

/* macds Wordmark — always lowercase "macds", Space Grotesk, hard negative tracking, one
   compact block. `sweep` runs the light-sweep reveal (the site's entry animation).
   Monogram variant renders "m" for favicon/avatar use. */
export function Wordmark({ size = 40, monogram = false, sweep = false, as = "span", style, ...rest }) {
  const Tag = as;
  const text = monogram ? "m" : "macds";
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (!sweep || !ref.current) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const el = ref.current;
    const g = "linear-gradient(100deg,transparent 12%,#000 42%,#000 58%,transparent 88%)";
    el.style.webkitMaskImage = g; el.style.maskImage = g;
    el.style.webkitMaskSize = "220% 100%"; el.style.maskSize = "220% 100%";
    el.style.webkitMaskPosition = "150% 0"; el.style.maskPosition = "150% 0";
    el.style.transition = "mask-position var(--dur-slow) var(--ease), -webkit-mask-position var(--dur-slow) var(--ease)";
    requestAnimationFrame(() => { el.style.webkitMaskPosition = "-50% 0"; el.style.maskPosition = "-50% 0"; });
    const t = setTimeout(() => { el.style.webkitMaskImage = "none"; el.style.maskImage = "none"; }, 900);
    return () => clearTimeout(t);
  }, [sweep]);
  return (
    <Tag ref={ref} aria-label="macds" style={{
      display: "inline-block", fontFamily: "var(--font-display)", fontWeight: "var(--fw-display-bold)",
      fontSize: size, lineHeight: 0.82, letterSpacing: "var(--tracking-hero)",
      color: "var(--text-primary)", ...style,
    }} {...rest}>{text}</Tag>
  );
}
