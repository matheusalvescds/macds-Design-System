/**
 * @startingPoint section="Brand" subtitle="Wordmark and monogram, with light-sweep reveal" viewport="700x200"
 */
export interface WordmarkProps {
  /** font-size in px */
  size?: number;
  /** render the single-letter "m" monogram (favicon, avatar) */
  monogram?: boolean;
  /** run the light-sweep reveal on mount; respects prefers-reduced-motion */
  sweep?: boolean;
  as?: "span" | "a" | "h1" | "div";
  style?: React.CSSProperties;
}
export declare function Wordmark(props: WordmarkProps): JSX.Element;
