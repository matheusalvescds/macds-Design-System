export interface IconProps {
  /** kebab-case icon slug, e.g. "arrow-up-right", "github" */
  name: string;
  /** "lucide" for UI glyphs (stroked), "simple" for brand marks (filled) */
  set?: "lucide" | "simple";
  size?: number;
  /** lucide only; the system uses 1.5 */
  strokeWidth?: number;
  style?: React.CSSProperties;
}
export declare function Icon(props: IconProps): JSX.Element;
