import React from "react";

/* macds IconButton — square hairline target, 44px minimum. */
export function IconButton({ label, children, href, size = 44, disabled, style, ...rest }) {
  const Tag = href ? "a" : "button";
  return (
    <Tag href={href} aria-label={label} title={label} disabled={!href && disabled ? true : undefined}
      style={{
        width: size, height: size, display: "inline-grid", placeItems: "center",
        background: "transparent", border: "var(--border-hairline)", borderRadius: "var(--radius-md)",
        color: "var(--icon)", cursor: disabled ? "not-allowed" : "pointer", opacity: disabled ? 0.4 : 1,
        boxShadow: "var(--edge-top)", transition: "box-shadow var(--dur-base) var(--ease), border-color var(--dur-base) var(--ease), color var(--dur-base) var(--ease)",
        ...style,
      }}
      onMouseEnter={(e) => { if (disabled) return; e.currentTarget.style.borderColor = "var(--border-lit)"; e.currentTarget.style.color = "var(--text-primary)"; e.currentTarget.style.boxShadow = "var(--edge-top-strong)"; }}
      onMouseLeave={(e) => { if (disabled) return; e.currentTarget.style.borderColor = "var(--border)"; e.currentTarget.style.color = "var(--icon)"; e.currentTarget.style.boxShadow = "var(--edge-top)"; }}
      {...rest}>
      {children}
    </Tag>
  );
}
