Hairline chip for stack items, project tech and filters. Mono type, lowercase as written.

```jsx
<Tag>react</Tag><Tag lit>typescript</Tag>
```
