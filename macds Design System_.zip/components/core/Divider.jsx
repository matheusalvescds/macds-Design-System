import React from "react";

/* macds Divider — a hairline that fades at both ends. `filament` sends a pulse of pure
   light travelling along it (ambient, transform-only). */
export function Divider({ filament = false, style, ...rest }) {
  return (
    <div role="separator" style={{ position: "relative", height: 1, width: "100%", overflow: "hidden", background: "var(--hairline-fade)", ...style }} {...rest}>
      {filament && <span style={{ position: "absolute", inset: 0, background: "var(--filament)", opacity: 0.5, animation: "macds-filament var(--dur-ambient) var(--ease-liquid) infinite", willChange: "transform" }} />}
    </div>
  );
}
