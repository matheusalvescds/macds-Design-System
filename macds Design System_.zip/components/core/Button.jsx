import React from "react";

/* macds Button — monochrome. Two levels only: `light` (lit surface, the primary CTA)
   and `ghost` (hairline). No color, no scale-on-hover: hover raises the edge light. */
export function Button({ variant = "ghost", size = "md", as = "button", href, icon, iconAfter, disabled, children, style, ...rest }) {
  const pad = size === "lg" ? "18px 30px" : size === "sm" ? "10px 16px" : "14px 24px";
  const fs = size === "lg" ? "var(--text-md)" : size === "sm" ? "var(--text-xs)" : "var(--text-sm)";
  const light = variant === "light";
  const base = {
    display: "inline-flex", alignItems: "center", gap: "var(--sp-3)", justifyContent: "center",
    minHeight: size === "sm" ? 36 : "var(--hit-min)", padding: pad, fontFamily: "var(--font-body)",
    fontSize: fs, fontWeight: "var(--fw-body-medium)", letterSpacing: "var(--tracking-tight)",
    lineHeight: 1, borderRadius: "var(--radius-md)", cursor: disabled ? "not-allowed" : "pointer",
    textDecoration: "none", position: "relative", overflow: "hidden",
    background: light ? "var(--mono-800)" : "transparent",
    color: light ? "var(--text-inverse)" : "var(--text-primary)",
    border: light ? "1px solid var(--mono-800)" : "var(--border-hairline-strong)",
    boxShadow: light ? "var(--halo-sm)" : "var(--edge-top)",
    opacity: disabled ? 0.4 : 1,
    transition: "box-shadow var(--dur-base) var(--ease), border-color var(--dur-base) var(--ease), background var(--dur-base) var(--ease), opacity var(--dur-base) var(--ease)",
    ...style,
  };
  const Tag = href ? "a" : as;
  const onEnter = (e) => { if (disabled) return; e.currentTarget.style.boxShadow = light ? "var(--halo-md)" : "var(--edge-top-strong)"; if (!light) e.currentTarget.style.borderColor = "var(--border-lit)"; };
  const onLeave = (e) => { if (disabled) return; e.currentTarget.style.boxShadow = light ? "var(--halo-sm)" : "var(--edge-top)"; if (!light) e.currentTarget.style.borderColor = "var(--border-strong)"; };
  return (
    <Tag href={href} disabled={!href && disabled ? true : undefined} aria-disabled={disabled || undefined}
      style={base} onMouseEnter={onEnter} onMouseLeave={onLeave} {...rest}>
      {icon}{children}{iconAfter}
    </Tag>
  );
}
