End-faded hairline used between sections and timeline rows.

```jsx
<Divider />
<Divider filament />
```

Use `filament` sparingly — at most one per viewport, as ambient life, not decoration.
