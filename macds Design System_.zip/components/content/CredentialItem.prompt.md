Row for formação e certificados — hairline list, never cards.

```jsx
<CredentialItem title="tecnólogo em análise e desenvolvimento de sistemas" org="instituição" year="2024" href="#" />
```
