export interface SocialLinkProps {
  /** Simple Icons slug: "github" | "linkedin" | "behance" | "gmail" */
  network: string;
  /** visible name, lowercase */
  label: string;
  /** handle or address, mono */
  handle?: string;
  href: string;
  style?: React.CSSProperties;
}
export declare function SocialLink(props: SocialLinkProps): JSX.Element;
