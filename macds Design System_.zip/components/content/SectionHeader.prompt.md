Opens every section: numbered mono label, oversized display title, optional lead.

```jsx
<SectionHeader index="03" label="projetos" title="interfaces que precisam aguentar produção" lead="Seleção de quatro." />
```

Title in lowercase sentence style, never a period. Keep lead under two sentences.
