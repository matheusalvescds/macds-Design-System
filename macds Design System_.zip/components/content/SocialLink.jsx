import React from "react";
import { Icon } from "../core/Icon.jsx";

/* macds SocialLink — large contact row: brand mark, handle, destination. The contact
   section is a list of these, not a grid of icon buttons. */
export function SocialLink({ network, label, handle, href, style, ...rest }) {
  return (
    <a href={href} style={{
      display: "flex", alignItems: "center", gap: "var(--sp-5)", padding: "var(--sp-5) 0",
      borderTop: "var(--border-hairline)", textDecoration: "none", minHeight: 72,
      transition: "padding-left var(--dur-base) var(--ease), border-color var(--dur-base) var(--ease)", ...style,
    }}
      onMouseEnter={(e) => { e.currentTarget.style.paddingLeft = "var(--sp-3)"; e.currentTarget.style.borderColor = "var(--border-lit)"; }}
      onMouseLeave={(e) => { e.currentTarget.style.paddingLeft = "0"; e.currentTarget.style.borderColor = "var(--border)"; }}
      {...rest}>
      <span style={{ color: "var(--icon)", display: "grid", placeItems: "center", width: 22 }}><Icon set="simple" name={network} size={20} /></span>
      <span style={{ flex: 1, fontFamily: "var(--font-display)", fontWeight: "var(--fw-display-medium)", fontSize: "var(--text-d3)", letterSpacing: "var(--tracking-tight)", color: "var(--text-primary)" }}>{label}</span>
      <span style={{ fontFamily: "var(--font-mono)", fontSize: "var(--text-xs)", color: "var(--text-secondary)" }}>{handle}</span>
      <Icon name="arrow-up-right" size={18} style={{ color: "var(--icon-muted)" }} />
    </a>
  );
}
