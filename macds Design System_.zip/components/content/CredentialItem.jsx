import React from "react";
import { Icon } from "../core/Icon.jsx";

/* macds CredentialItem — formação e certificados row: institution, title, year, optional
   verification link. Hairline separated, no cards. */
export function CredentialItem({ title, org, year, href, style, ...rest }) {
  const content = (
    <>
      <div style={{ display: "grid", gap: "var(--sp-1)" }}>
        <span style={{ fontFamily: "var(--font-display)", fontWeight: "var(--fw-display-medium)", fontSize: "var(--text-md)", letterSpacing: "var(--tracking-tight)", color: "var(--text-primary)" }}>{title}</span>
        <span style={{ fontSize: "var(--text-sm)", color: "var(--text-secondary)" }}>{org}</span>
      </div>
      <span style={{ display: "inline-flex", alignItems: "center", gap: "var(--sp-3)", fontFamily: "var(--font-mono)", fontSize: "var(--text-xs)", color: "var(--text-tertiary)" }}>
        {year}{href && <Icon name="arrow-up-right" size={14} />}
      </span>
    </>
  );
  const base = { display: "flex", alignItems: "center", justifyContent: "space-between", gap: "var(--sp-5)", padding: "var(--sp-5) 0", borderTop: "var(--border-hairline)", minHeight: "var(--hit-min)", textDecoration: "none", ...style };
  return href
    ? <a href={href} style={base} {...rest}>{content}</a>
    : <div style={base} {...rest}>{content}</div>;
}
