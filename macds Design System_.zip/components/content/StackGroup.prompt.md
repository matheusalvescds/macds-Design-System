Competence cluster for the stack section — mono heading plus chips.

```jsx
<StackGroup heading="front-end" items={["react","typescript","next.js"]} lit={["react"]} />
```

Three to five groups per section. No proficiency bars or percentages.
