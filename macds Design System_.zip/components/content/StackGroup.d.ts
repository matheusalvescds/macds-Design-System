export interface StackGroupProps {
  heading: string;
  items?: string[];
  /** subset of items rendered lit — the strongest tools */
  lit?: string[];
  style?: React.CSSProperties;
}
export declare function StackGroup(props: StackGroupProps): JSX.Element;
