export interface TimelineItemProps {
  /** mono period, e.g. "2023 — agora" */
  period: string;
  role: string;
  org?: string;
  description?: string;
  stack?: string[];
  /** lights the spine node in pure white */
  current?: boolean;
  style?: React.CSSProperties;
}
export declare function TimelineItem(props: TimelineItemProps): JSX.Element;
