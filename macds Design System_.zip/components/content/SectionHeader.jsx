import React from "react";
import { Eyebrow } from "../core/Eyebrow.jsx";

/* macds SectionHeader — index + label, huge display title, optional short lead.
   The vertical space above and below is part of the component. */
export function SectionHeader({ index, label, title, lead, style, ...rest }) {
  return (
    <header style={{ display: "grid", gap: "var(--sp-5)", marginBottom: "var(--sp-8)", ...style }} {...rest}>
      {label && <Eyebrow index={index}>{label}</Eyebrow>}
      <h2 style={{ margin: 0, fontFamily: "var(--font-display)", fontWeight: "var(--fw-display-semibold)", fontSize: "var(--text-d1)", lineHeight: "var(--leading-display)", letterSpacing: "var(--tracking-display)", color: "var(--text-primary)", maxWidth: "18ch" }}>{title}</h2>
      {lead && <p style={{ margin: 0, maxWidth: "var(--measure)", fontSize: "var(--text-lg)", lineHeight: "var(--leading-snug)", color: "var(--text-secondary)" }}>{lead}</p>}
    </header>
  );
}
