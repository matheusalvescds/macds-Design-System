Contact row — the contact section is a stacked list of these, full width.

```jsx
<SocialLink network="github" label="github" handle="/macds" href="https://github.com/macds" />
```

Hover shifts the row right and lights its rule; no color, no scale.
