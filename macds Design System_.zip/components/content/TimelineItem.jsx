import React from "react";
import { Tag } from "../core/Tag.jsx";

/* macds TimelineItem — experience row. Mono period on the left, role and company on the
   right, hairline rule between rows, a lit node on the spine. */
export function TimelineItem({ period, role, org, description, stack = [], current = false, style, ...rest }) {
  return (
    <li style={{ position: "relative", listStyle: "none", display: "grid", gridTemplateColumns: "minmax(120px,180px) 1fr", gap: "var(--sp-6)", padding: "var(--sp-6) 0", borderTop: "var(--border-hairline)", ...style }} {...rest}>
      <span aria-hidden="true" style={{ position: "absolute", top: -3, left: 0, width: 5, height: 5, borderRadius: "var(--radius-full)", background: current ? "var(--light-pure)" : "var(--mono-400)", boxShadow: current ? "var(--halo-sm)" : "none" }} />
      <div style={{ fontFamily: "var(--font-mono)", fontSize: "var(--text-xs)", color: "var(--text-tertiary)", letterSpacing: 0, paddingTop: 4 }}>{period}</div>
      <div style={{ display: "grid", gap: "var(--sp-3)" }}>
        <h3 style={{ margin: 0, fontFamily: "var(--font-display)", fontWeight: "var(--fw-display-medium)", fontSize: "var(--text-d3)", letterSpacing: "var(--tracking-tight)", lineHeight: "var(--leading-snug)", color: "var(--text-primary)" }}>
          {role}{org && <span style={{ color: "var(--text-secondary)" }}> · {org}</span>}
        </h3>
        {description && <p style={{ margin: 0, maxWidth: "var(--measure)", fontSize: "var(--text-sm)", lineHeight: "var(--leading-body)", color: "var(--text-secondary)" }}>{description}</p>}
        {stack.length > 0 && <div style={{ display: "flex", flexWrap: "wrap", gap: "var(--sp-2)" }}>{stack.map((s) => <Tag key={s}>{s}</Tag>)}</div>}
      </div>
    </li>
  );
}
