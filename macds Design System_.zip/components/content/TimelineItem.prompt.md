Experience row for the timeline section. Render inside a `<ul style={{margin:0,padding:0}}>`.

```jsx
<TimelineItem current period="2023 — agora" role="desenvolvedor front-end" org="empresa" description="…" stack={["react","node"]} />
```

Only the most recent item gets `current`. Periods use an em dash and "agora" for present.
