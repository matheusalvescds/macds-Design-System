export interface CredentialItemProps {
  title: string;
  org?: string;
  year?: string;
  /** verification/credential URL — renders the arrow affordance */
  href?: string;
  style?: React.CSSProperties;
}
export declare function CredentialItem(props: CredentialItemProps): JSX.Element;
