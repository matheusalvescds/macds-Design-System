import React from "react";
import { Tag } from "../core/Tag.jsx";

/* macds StackGroup — a competence cluster: mono heading + chips. */
export function StackGroup({ heading, items = [], lit = [], style, ...rest }) {
  return (
    <div style={{ display: "grid", gap: "var(--sp-4)", ...style }} {...rest}>
      <h3 style={{ margin: 0, fontFamily: "var(--font-mono)", fontSize: "var(--text-label)", textTransform: "uppercase", letterSpacing: "var(--tracking-label)", color: "var(--text-secondary)", fontWeight: 400 }}>{heading}</h3>
      <div style={{ display: "flex", flexWrap: "wrap", gap: "var(--sp-2)" }}>
        {items.map((i) => <Tag key={i} lit={lit.includes(i)}>{i}</Tag>)}
      </div>
    </div>
  );
}
