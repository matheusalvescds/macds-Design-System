export interface SectionHeaderProps {
  /** zero-padded counter, e.g. "03" */
  index?: string;
  /** mono uppercase label */
  label?: string;
  title: string;
  /** one or two sentences maximum */
  lead?: string;
  style?: React.CSSProperties;
}
export declare function SectionHeader(props: SectionHeaderProps): JSX.Element;
