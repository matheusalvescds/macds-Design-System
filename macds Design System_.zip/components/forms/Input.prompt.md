Underline field for the contact form; `textarea` for the message.

```jsx
<Input label="e-mail" type="email" placeholder="voce@empresa.com" />
<Input label="mensagem" textarea rows={5} hint="respondo em até dois dias" />
```

Errors have no color — the rule brightens and the message is stated plainly. Focus lights the rule only.
