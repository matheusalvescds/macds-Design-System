import React from "react";

/* macds Input — hairline underline field. Focus lights the rule; no fill change, no glow
   on the whole box. Label sits above, mono uppercase. */
export function Input({ label, id, type = "text", hint, error, textarea = false, rows = 4, style, ...rest }) {
  const rid = id || React.useId();
  const [focus, setFocus] = React.useState(false);
  const field = {
    width: "100%", background: "transparent", border: "0", borderBottom: `1px solid ${error ? "var(--mono-700)" : focus ? "var(--light-70)" : "var(--border-strong)"}`,
    padding: "var(--sp-3) 0", color: "var(--text-primary)", fontFamily: "var(--font-body)",
    fontSize: "var(--text-md)", letterSpacing: "var(--tracking-body)", outline: "none",
    borderRadius: 0, resize: textarea ? "vertical" : undefined, minHeight: textarea ? undefined : "var(--hit-min)",
    transition: "border-color var(--dur-base) var(--ease)",
  };
  const Tag = textarea ? "textarea" : "input";
  return (
    <div style={{ display: "grid", gap: "var(--sp-2)", ...style }}>
      {label && <label htmlFor={rid} style={{ fontFamily: "var(--font-mono)", fontSize: "var(--text-label)", textTransform: "uppercase", letterSpacing: "var(--tracking-label)", color: focus ? "var(--text-primary)" : "var(--text-secondary)", transition: "color var(--dur-base) var(--ease)" }}>{label}</label>}
      <Tag id={rid} type={textarea ? undefined : type} rows={textarea ? rows : undefined} style={field}
        onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
        aria-invalid={error ? true : undefined} aria-describedby={hint || error ? `${rid}-d` : undefined} {...rest} />
      {(hint || error) && <p id={`${rid}-d`} style={{ margin: 0, fontFamily: "var(--font-mono)", fontSize: "var(--text-xs)", color: error ? "var(--text-primary)" : "var(--text-tertiary)" }}>{error || hint}</p>}
    </div>
  );
}
