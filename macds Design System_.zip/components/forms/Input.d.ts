export interface InputProps {
  label?: string;
  id?: string;
  type?: string;
  /** mono helper line under the field */
  hint?: string;
  /** error message; replaces hint and lightens the rule (no red — the system has no color) */
  error?: string;
  /** render a textarea instead */
  textarea?: boolean;
  rows?: number;
  placeholder?: string;
  style?: React.CSSProperties;
}
export declare function Input(props: InputProps): JSX.Element;
