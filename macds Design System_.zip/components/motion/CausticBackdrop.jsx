import React from "react";

/* macds CausticBackdrop — slow luminance movement behind the hero. Layered radial light
   plus an optional reference plate in screen blend. Transform-only animation; frozen
   below 768px and under prefers-reduced-motion. */
export function CausticBackdrop({ plate, intensity = 1, children, style, ...rest }) {
  return (
    <div style={{ position: "absolute", inset: 0, overflow: "hidden", background: "var(--canvas)", ...style }} aria-hidden="true" {...rest}>
      <div className="macds-static-below-md" style={{
        position: "absolute", inset: "-12%", background: "var(--caustic-field)",
        opacity: 0.9 * intensity, filter: "blur(18px)",
        animation: "macds-caustic var(--dur-ambient) ease-in-out infinite", willChange: "transform",
      }} />
      {plate && <img src={plate} alt="" loading="lazy" className="macds-static-below-md macds-plate" style={{
        position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover",
        opacity: 0.5 * intensity, mixBlendMode: "screen",
        animation: "macds-caustic calc(var(--dur-ambient) * 2.4) ease-in-out infinite reverse", willChange: "transform",
      }} />}
      <div style={{ position: "absolute", inset: 0, background: "var(--depth-inset)" }} />
      <div className="macds-grain macds-grain--local" style={{ position: "absolute" }} />
      {children}
    </div>
  );
}
