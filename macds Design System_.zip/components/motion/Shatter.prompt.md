Exit fragmentation — the element shatters into shards as it leaves the viewport. Only for exits, never entrances.

```jsx
<Shatter shards={7}><h2 className="macds-d1">fim da seção</h2></Shatter>
```

Duplicates its children per shard, so keep the subtree small (a heading, a mark) and never wrap interactive content.
