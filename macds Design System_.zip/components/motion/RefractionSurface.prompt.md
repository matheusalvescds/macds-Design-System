Glass-refraction hover for cards. Wrap a surface; the cursor distorts it and drags a specular highlight.

```jsx
<RefractionSurface amount={16} radius="var(--radius-lg)">
  <ProjectCard … />
</RefractionSurface>
```

Never combined with hover scale or a fade. Disabled below 768px and under reduced motion — the undistorted card is the designed fallback, not a degraded one.
