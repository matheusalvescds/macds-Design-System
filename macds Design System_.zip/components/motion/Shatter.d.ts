export interface ShatterProps {
  children?: React.ReactNode;
  /** number of vertical shards; 5–9 reads as glass, more reads as noise */
  shards?: number;
  /** px of drift at full exit */
  spread?: number;
  style?: React.CSSProperties;
}
export declare function Shatter(props: ShatterProps): JSX.Element;

/** @deprecated alias of Shatter */
export declare function Fragment(props: ShatterProps): JSX.Element;
