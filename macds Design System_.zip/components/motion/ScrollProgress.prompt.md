1px filament at the top of the page showing read position.

```jsx
<ScrollProgress />
```

Decorative and `aria-hidden`; mount once, next to `<Grain />`.
