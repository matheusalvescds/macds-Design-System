Scroll-linked depth for plates and hero imagery — transform only.

```jsx
<Parallax distance={90} scale={0.05}><img src="assets/imagery/retrato-luz.png" alt="" /></Parallax>
```

Use on imagery and light layers, never on text blocks or interactive controls.
