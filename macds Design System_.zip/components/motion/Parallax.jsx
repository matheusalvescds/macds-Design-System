import React from "react";
import { useScrollProgress } from "./ScrollMask.jsx";

/* macds Parallax — scroll-linked translate (and optional scale) on transform only.
   Depth in a monochrome system comes from differential speed, not from color. */
export function Parallax({ children, distance = 80, scale = 0, as = "div", style, ...rest }) {
  const Tag = as;
  const ref = React.useRef(null);
  const p = useScrollProgress(ref, { from: 1.1, to: -0.2 });
  const y = (p - 0.5) * -distance;
  const s = 1 + (scale ? (1 - Math.abs(p - 0.5) * 2) * scale : 0);
  return <Tag ref={ref} style={{ transform: `translate3d(0,${y}px,0) scale(${s})`, willChange: "transform", ...style }} {...rest}>{children}</Tag>;
}
