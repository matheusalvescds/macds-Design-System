import React from "react";

/* macds useScrollProgress — 0→1 progress of an element crossing the viewport, driven by a
   single rAF-throttled scroll listener. Returns 0 (start) under prefers-reduced-motion. */
export function useScrollProgress(ref, { from = 1, to = 0.15 } = {}) {
  const [p, setP] = React.useState(0);
  React.useEffect(() => {
    if (typeof window === "undefined") return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) { setP(1); return; }
    let raf = 0;
    const measure = () => {
      const el = ref.current; if (!el) return;
      const r = el.getBoundingClientRect(), vh = window.innerHeight || 1;
      const start = vh * from, end = vh * to;
      const v = (start - r.top) / Math.max(1, start - end);
      setP(Math.min(1, Math.max(0, v)));
    };
    const onScroll = () => { cancelAnimationFrame(raf); raf = requestAnimationFrame(measure); };
    measure();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => { window.removeEventListener("scroll", onScroll); window.removeEventListener("resize", onScroll); cancelAnimationFrame(raf); };
  }, [ref, from, to]);
  return p;
}

/* macds ScrollMask — the light sweep bound to scroll instead of to time. The mask position
   tracks scroll progress, so the text is written by light as the page moves. Fully visible
   (mask removed) once complete and under reduced motion. */
export function ScrollMask({ children, as = "div", softness = 34, style, ...rest }) {
  const Tag = as;
  const ref = React.useRef(null);
  const p = useScrollProgress(ref, { from: 0.95, to: 0.35 });
  const done = p >= 1;
  const g = `linear-gradient(100deg,#000 0%,#000 ${Math.max(0, p * 100 - softness)}%,rgba(0,0,0,.25) ${p * 100}%,rgba(0,0,0,0) ${Math.min(100, p * 100 + softness * 0.4)}%)`;
  return (
    <Tag ref={ref} style={{
      ...(done ? {} : { WebkitMaskImage: g, maskImage: g, WebkitMaskSize: "100% 100%", maskSize: "100% 100%" }),
      ...style,
    }} {...rest}>{children}</Tag>
  );
}
