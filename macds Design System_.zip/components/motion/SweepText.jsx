import React from "react";

/* macds SweepText — the signature reveal. A white gradient crosses a text mask, per
   character, with the system easing. NOT a fade or a slide. Static and fully legible
   under prefers-reduced-motion. */
export function SweepText({ children, as = "span", delay = 0, stagger = 26, style, ...rest }) {
  const Tag = as;
  /* children may arrive as a string, an array, or a wrapped node depending on how the
     component is mounted — flatten to text, and fall back to rendering as-is. */
  const flatten = (c) => React.Children.toArray(c).map((n) =>
    (typeof n === "string" || typeof n === "number") ? String(n) : (n && n.props ? flatten(n.props.children) : "")).join("");
  const text = flatten(children);
  const reduce = typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const [on, setOn] = React.useState(reduce);
  React.useEffect(() => { if (reduce) return; const t = setTimeout(() => setOn(true), delay); return () => clearTimeout(t); }, [delay, reduce]);
  if (!text) return <Tag style={style} {...rest}>{children}</Tag>;
  return (
    <Tag style={{ display: "inline-block", ...style }} {...rest}>
      {text.split("").map((ch, i) => (
        <span key={i} aria-hidden={ch === " " ? "true" : undefined} style={{
          display: "inline-block", whiteSpace: "pre",
          color: on ? "var(--text-primary)" : "transparent",
          textShadow: on ? "none" : "0 0 24px rgba(255,255,255,.55)",
          transform: on ? "none" : "translate3d(0,0.14em,0)",
          transition: `color var(--dur-mid) var(--ease) ${i * stagger}ms, transform var(--dur-mid) var(--ease) ${i * stagger}ms, text-shadow var(--dur-slow) var(--ease) ${i * stagger}ms`,
        }}>{ch}</span>
      ))}
    </Tag>
  );
}
