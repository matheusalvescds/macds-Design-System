export interface ScrollProgressProps {
  style?: React.CSSProperties;
}
export declare function ScrollProgress(props: ScrollProgressProps): JSX.Element;
