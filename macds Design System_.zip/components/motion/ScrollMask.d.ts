export interface ScrollMaskProps {
  children?: React.ReactNode;
  as?: "div" | "h2" | "p" | "span" | "section";
  /** width of the soft edge of the light front, in % of the element */
  softness?: number;
  style?: React.CSSProperties;
}
export declare function ScrollMask(props: ScrollMaskProps): JSX.Element;
/** 0→1 progress of an element crossing the viewport; 1 immediately under reduced motion */
export declare function useScrollProgress(ref: React.RefObject<HTMLElement>, opts?: { from?: number; to?: number }): number;
