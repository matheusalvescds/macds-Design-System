import React from "react";

/* macds ScrollProgress — a 1px filament across the top of the page whose width is the
   read position. The only always-on scroll indicator in the system. */
export function ScrollProgress({ style, ...rest }) {
  const [p, setP] = React.useState(0);
  React.useEffect(() => {
    let raf = 0;
    const measure = () => {
      const h = document.documentElement.scrollHeight - window.innerHeight;
      setP(h > 0 ? window.scrollY / h : 0);
    };
    const onScroll = () => { cancelAnimationFrame(raf); raf = requestAnimationFrame(measure); };
    measure();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => { window.removeEventListener("scroll", onScroll); window.removeEventListener("resize", onScroll); cancelAnimationFrame(raf); };
  }, []);
  return (
    <div aria-hidden="true" style={{ position: "fixed", top: 0, left: 0, right: 0, height: 1, zIndex: 60, background: "var(--border)", ...style }} {...rest}>
      <div style={{ height: "100%", width: `${p * 100}%`, background: "var(--filament)", transformOrigin: "left" }} />
    </div>
  );
}
