export interface MagneticProps {
  children?: React.ReactNode;
  /** max px displacement toward the cursor */
  pull?: number;
  /** max deg of shear — keep under 2 */
  skew?: number;
  as?: "div" | "span" | "a";
  style?: React.CSSProperties;
}
export declare function Magnetic(props: MagneticProps): JSX.Element;
