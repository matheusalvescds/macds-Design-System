Light-sweep reveal with per-character stagger — the system's only text entrance.

```jsx
<SweepText as="h1" className="macds-hero" delay={120}>matheus alves</SweepText>
```

Use once or twice per page (hero, one section opener). Never on already-visible elements after scroll, never as a fade. Text is present and legible immediately under `prefers-reduced-motion`.
