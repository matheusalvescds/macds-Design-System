export interface MarqueeProps {
  /** strings rendered on the track; duplicated internally for the loop */
  items?: string[];
  /** seconds for one full loop; higher is slower */
  speed?: number;
  separator?: string;
  style?: React.CSSProperties;
}
export declare function Marquee(props: MarqueeProps): JSX.Element;
