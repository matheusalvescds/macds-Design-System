export interface CausticBackdropProps {
  /** path to a monochrome light/glass plate, e.g. assets/imagery/formas-liquidas.png */
  plate?: string;
  /** 0–1.4 multiplier on light amount */
  intensity?: number;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function CausticBackdrop(props: CausticBackdropProps): JSX.Element;
