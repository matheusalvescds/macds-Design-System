import React from "react";

/* macds Magnetic — the element leans toward the cursor and deforms slightly. Transform
   only; disabled under reduced motion and on touch. */
export function Magnetic({ children, pull = 14, skew = 1.4, as = "div", style, ...rest }) {
  const Tag = as;
  const ref = React.useRef(null);
  const ok = () => typeof window !== "undefined" && window.matchMedia("(hover: hover)").matches && !window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  return (
    <Tag ref={ref} style={{ display: "inline-block", transition: "transform var(--dur-base) var(--ease)", willChange: "transform", ...style }}
      onMouseMove={(e) => { if (!ok()) return; const r = e.currentTarget.getBoundingClientRect();
        const dx = (e.clientX - (r.left + r.width / 2)) / (r.width / 2), dy = (e.clientY - (r.top + r.height / 2)) / (r.height / 2);
        e.currentTarget.style.transform = `translate3d(${dx * pull}px,${dy * pull}px,0) skew(${-dx * skew}deg,${dy * skew * 0.4}deg)`; }}
      onMouseLeave={(e) => { if (!ok()) return; e.currentTarget.style.transform = "none"; }}
      {...rest}>{children}</Tag>
  );
}
