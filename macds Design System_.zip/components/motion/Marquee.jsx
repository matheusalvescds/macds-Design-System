import React from "react";

/* macds Marquee — infinite light ticker. One continuous translate on a duplicated track,
   masked to fade at both edges. Pauses on hover and under reduced motion. */
export function Marquee({ items = [], speed = 42, separator = "·", style, ...rest }) {
  const [paused, setPaused] = React.useState(false);
  const reduce = typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const track = [...items, ...items];
  const fade = "linear-gradient(90deg,transparent,#000 8%,#000 92%,transparent)";
  return (
    <div onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)}
      style={{ overflow: "hidden", WebkitMaskImage: fade, maskImage: fade, ...style }} {...rest}>
      <div style={{
        display: "flex", gap: "var(--sp-6)", width: "max-content", alignItems: "center",
        animation: reduce ? "none" : `macds-marquee ${speed}s linear infinite`,
        animationPlayState: paused ? "paused" : "running", willChange: "transform",
      }}>
        {track.map((t, i) => (
          <span key={i} style={{ display: "inline-flex", alignItems: "center", gap: "var(--sp-6)", fontFamily: "var(--font-display)", fontWeight: "var(--fw-display-medium)", fontSize: "var(--text-d3)", letterSpacing: "var(--tracking-tight)", color: i % 2 ? "var(--text-secondary)" : "var(--text-primary)", whiteSpace: "nowrap" }}>
            {t}<span aria-hidden="true" style={{ color: "var(--text-tertiary)" }}>{separator}</span>
          </span>
        ))}
      </div>
    </div>
  );
}
