import React from "react";
import { useScrollProgress } from "./ScrollMask.jsx";

/* macds Shatter — fragmentação: the element breaks into vertical shards that drift apart
   and dim as it leaves the viewport. Clip-path + transform only; no fade of the whole box. */
export function Shatter({ children, shards = 7, spread = 90, style, ...rest }) {
  const ref = React.useRef(null);
  const p = useScrollProgress(ref, { from: 0.15, to: -0.55 });
  const out = 1 - p;                       // 1 while in view, → 0 as it exits upward
  const k = Math.max(0, Math.min(1, 1 - out));
  const list = Array.from({ length: shards }, (_, i) => i);
  const measure = 100 / shards;
  return (
    <div ref={ref} style={{ position: "relative", ...style }} {...rest}>
      {list.map((i) => {
        const dir = i % 2 ? 1 : -1;
        const seed = ((i * 37) % 11) / 11;
        return (
          <div key={i} aria-hidden={i > 0 ? "true" : undefined} style={{
            ...(i === 0 ? {} : { position: "absolute", inset: 0 }),
            clipPath: `polygon(${i * measure}% 0,${(i + 1) * measure}% 0,${(i + 1) * measure}% 100%,${i * measure}% 100%)`,
            transform: `translate3d(${dir * k * spread * (0.4 + seed)}px,${-k * spread * seed * 0.6}px,0) rotate(${dir * k * 2.5 * seed}deg)`,
            opacity: 1 - k * 0.85,
            willChange: "transform,opacity",
          }}>{children}</div>
        );
      })}
    </div>
  );
}

/* legacy alias — do not remove; consumers may still reference the old name */
export const Fragment = Shatter;
