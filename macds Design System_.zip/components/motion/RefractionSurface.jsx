import React from "react";

/* macds RefractionSurface — glass hover. An SVG feDisplacementMap distorts the whole
   subtree as the cursor approaches, and a specular highlight tracks the pointer.
   Below 768px (or reduced motion) the filter is never applied: the static surface is the
   real fallback. Used on project cards. */
let uid = 0;
export function RefractionSurface({ children, amount = 16, radius = "var(--radius-lg)", style, ...rest }) {
  const id = React.useMemo(() => `macds-refract-${++uid}`, []);
  const host = React.useRef(null);
  const disp = React.useRef(null);
  const [pt, setPt] = React.useState({ x: 50, y: 50, on: false });
  const raf = React.useRef(0);

  const enabled = () => typeof window !== "undefined"
    && window.matchMedia("(min-width: 769px)").matches
    && !window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  const drive = (target) => {
    cancelAnimationFrame(raf.current);
    const node = disp.current; if (!node) return;
    const from = parseFloat(node.getAttribute("scale")) || 0;
    const t0 = performance.now(), d = 550;
    const step = (t) => {
      const p = Math.min(1, (t - t0) / d);
      const e = 1 - Math.pow(1 - p, 3);
      node.setAttribute("scale", String(from + (target - from) * e));
      if (p < 1) raf.current = requestAnimationFrame(step);
    };
    raf.current = requestAnimationFrame(step);
  };

  return (
    <div ref={host} style={{ position: "relative", borderRadius: radius, isolation: "isolate", ...style }}
      onMouseEnter={() => { if (!enabled()) return; host.current.style.filter = `url(#${id})`; drive(amount); setPt((p) => ({ ...p, on: true })); }}
      onMouseLeave={() => { if (!enabled()) return; drive(0); setPt((p) => ({ ...p, on: false })); setTimeout(() => { if (host.current) host.current.style.filter = "none"; }, 560); }}
      onMouseMove={(e) => { if (!enabled()) return; const r = e.currentTarget.getBoundingClientRect(); setPt({ x: ((e.clientX - r.left) / r.width) * 100, y: ((e.clientY - r.top) / r.height) * 100, on: true }); }}
      {...rest}>
      <svg width="0" height="0" style={{ position: "absolute" }} aria-hidden="true">
        <filter id={id} x="-8%" y="-8%" width="116%" height="116%" colorInterpolationFilters="sRGB">
          <feTurbulence type="fractalNoise" baseFrequency="0.014 0.022" numOctaves="2" seed="7" result="n" />
          <feDisplacementMap ref={disp} in="SourceGraphic" in2="n" scale="0" xChannelSelector="R" yChannelSelector="G" />
        </filter>
      </svg>
      {children}
      <span aria-hidden="true" style={{
        position: "absolute", inset: 0, borderRadius: radius, pointerEvents: "none",
        background: `radial-gradient(38% 38% at ${pt.x}% ${pt.y}%, rgba(255,255,255,.14), transparent 70%)`,
        opacity: pt.on ? 1 : 0, transition: "opacity var(--dur-base) var(--ease)",
      }} />
    </div>
  );
}
