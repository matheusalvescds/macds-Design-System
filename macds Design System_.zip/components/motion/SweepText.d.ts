export interface SweepTextProps {
  /** plain string — split per character for the stagger */
  children?: string;
  as?: "span" | "h1" | "h2" | "p" | "div";
  /** ms before the sweep starts */
  delay?: number;
  /** ms between characters; system default 26 */
  stagger?: number;
  style?: React.CSSProperties;
}
export declare function SweepText(props: SweepTextProps): JSX.Element;
