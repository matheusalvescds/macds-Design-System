Light-sweep reveal driven by scroll position instead of a timer — headings get written by light as the page moves.

```jsx
<ScrollMask as="h2" className="macds-d1">interfaces que aguentam produção</ScrollMask>
```

Also exports `useScrollProgress(ref)` for any scroll-linked value. Never use it to hide body copy that a recruiter needs to Ctrl+F — the mask is removed at 100% and skipped entirely under reduced motion.
