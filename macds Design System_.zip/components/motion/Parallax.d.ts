export interface ParallaxProps {
  children?: React.ReactNode;
  /** total px of travel across the whole crossing; 40–120 reads as depth, above 200 as glitch */
  distance?: number;
  /** extra scale at mid-crossing, e.g. 0.06 */
  scale?: number;
  as?: "div" | "figure" | "span";
  style?: React.CSSProperties;
}
export declare function Parallax(props: ParallaxProps): JSX.Element;
