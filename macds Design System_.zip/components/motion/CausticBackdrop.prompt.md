Absolutely-positioned caustic light field for hero and section backdrops.

```jsx
<section style={{position:'relative'}}>
  <CausticBackdrop plate="assets/imagery/formas-liquidas.png" intensity={0.9} />
  <div className="macds-silence">…text…</div>
</section>
```

Always pair with a zona de silêncio (`.macds-silence` or a solid plate) under any text. Freezes below 768px and under reduced motion.
