Cursor-magnetic wrapper with slight shear — for CTAs and the contact block, not for body text.

```jsx
<Magnetic pull={12}><Button variant="light">ver projetos</Button></Magnetic>
```

Off on touch and under reduced motion. One or two per page at most.
