export interface RefractionSurfaceProps {
  children?: React.ReactNode;
  /** peak feDisplacementMap scale on hover; 12–20 reads as glass, above 28 as damage */
  amount?: number;
  /** must match the wrapped surface's radius so the specular highlight clips correctly */
  radius?: string;
  style?: React.CSSProperties;
}
export declare function RefractionSurface(props: RefractionSurfaceProps): JSX.Element;
