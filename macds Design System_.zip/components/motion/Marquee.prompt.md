Infinite ticker for the stack line — ambient motion that never asks for attention.

```jsx
<Marquee items={["react","typescript","gsap","webgl"]} speed={46} />
```

Edges fade via mask; pauses on hover and under reduced motion. One per page.
