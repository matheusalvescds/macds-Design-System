import React from "react";
import { Tag } from "../core/Tag.jsx";
import { Icon } from "../core/Icon.jsx";
import { RefractionSurface } from "../motion/RefractionSurface.jsx";

/* macds ProjectCard — image plate on top, hairline surface below, refraction on hover.
   Text always sits on solid surface, never over the plate. */
export function ProjectCard({ title, year, summary, stack = [], image, href = "#", style, ...rest }) {
  return (
    <RefractionSurface radius="var(--radius-lg)" style={style}>
      <a href={href} style={{
        display: "block", textDecoration: "none", borderRadius: "var(--radius-lg)", overflow: "hidden",
        background: "var(--surface-1)", border: "var(--border-hairline)", boxShadow: "var(--edge-top)",
      }} {...rest}>
        <div style={{ position: "relative", aspectRatio: "16 / 10", background: "var(--mono-050)", overflow: "hidden" }}>
          {image && <img className="macds-plate" src={image} alt="" loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover" }} />}
          <span aria-hidden="true" style={{ position: "absolute", inset: 0, background: "var(--silence-veil-bottom)", opacity: 0.55 }} />
        </div>
        <div style={{ padding: "var(--sp-5) var(--sp-5) var(--sp-6)", display: "grid", gap: "var(--sp-4)" }}>
          <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", gap: "var(--sp-4)" }}>
            <h3 style={{ margin: 0, fontFamily: "var(--font-display)", fontWeight: "var(--fw-display-medium)", fontSize: "var(--text-d3)", letterSpacing: "var(--tracking-tight)", lineHeight: "var(--leading-snug)", color: "var(--text-primary)" }}>{title}</h3>
            <span style={{ fontFamily: "var(--font-mono)", fontSize: "var(--text-xs)", color: "var(--text-tertiary)" }}>{year}</span>
          </div>
          <p style={{ margin: 0, fontSize: "var(--text-sm)", lineHeight: "var(--leading-body)", color: "var(--text-secondary)" }}>{summary}</p>
          <div style={{ display: "flex", flexWrap: "wrap", gap: "var(--sp-2)" }}>{stack.map((s) => <Tag key={s}>{s}</Tag>)}</div>
          <span style={{ display: "inline-flex", alignItems: "center", gap: "var(--sp-2)", fontFamily: "var(--font-mono)", fontSize: "var(--text-label)", textTransform: "uppercase", letterSpacing: "var(--tracking-label)", color: "var(--text-primary)" }}>
            ver projeto <Icon name="arrow-up-right" size={14} />
          </span>
        </div>
      </a>
    </RefractionSurface>
  );
}
