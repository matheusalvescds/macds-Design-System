The noise overlay. Every macds page and every exported piece has exactly one.

```jsx
<Grain />                    {/* page level */}
<Grain local opacity={0.05} />  {/* inside a hero or a 1080px LinkedIn artboard */}
```

Non-negotiable: no macds surface ships without grain.
