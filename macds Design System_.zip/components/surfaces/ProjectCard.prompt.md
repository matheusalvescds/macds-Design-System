The projects grid unit — image plate, then hairline surface with title, summary and stack.

```jsx
<ProjectCard title="painel de operações" year="2025" summary="…" stack={["react","typescript","gsap"]} image="assets/imagery/curvas-metalicas.png" href="#" />
```

Comes with refraction hover built in — do not wrap it in another RefractionSurface. Images are always grayscale; copy never sits on top of the plate.
