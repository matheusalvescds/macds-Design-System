import React from "react";

/* macds Grain — the mandatory 4% noise overlay. Fixed by default (whole page), local when
   scoped to a surface. Without it the black reads dead and gradients band in compression. */
export function Grain({ local = false, opacity, style, ...rest }) {
  return <div aria-hidden="true" className={local ? "macds-grain macds-grain--local" : "macds-grain"} style={{ opacity, ...style }} {...rest} />;
}
