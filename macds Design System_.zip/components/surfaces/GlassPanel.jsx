import React from "react";

/* macds GlassPanel — dark glass: blurred backdrop, light top edge, no diffuse shadow. */
export function GlassPanel({ children, radius = "var(--radius-lg)", padding = "var(--sp-6)", strong = false, style, ...rest }) {
  return (
    <div style={{
      position: "relative", padding, borderRadius: radius,
      background: `var(--glass-bg), ${strong ? "var(--surface-2)" : "var(--surface-glass)"}`,
      backdropFilter: `blur(${strong ? "var(--glass-blur-strong)" : "var(--glass-blur)"}) saturate(0)`,
      WebkitBackdropFilter: `blur(${strong ? "var(--glass-blur-strong)" : "var(--glass-blur)"}) saturate(0)`,
      border: "1px solid var(--glass-border)", boxShadow: "var(--edge-top), var(--depth-drop)",
      ...style,
    }} {...rest}>{children}</div>
  );
}
