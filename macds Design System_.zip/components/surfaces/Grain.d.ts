export interface GrainProps {
  /** absolute inside a positioned parent instead of fixed to the viewport */
  local?: boolean;
  /** override the 0.04 system value; only for print/export pieces */
  opacity?: number;
  style?: React.CSSProperties;
}
export declare function Grain(props: GrainProps): JSX.Element;
