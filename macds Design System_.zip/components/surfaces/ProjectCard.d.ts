/**
 * @startingPoint section="Content" subtitle="Project card with glass-refraction hover" viewport="700x420"
 */
export interface ProjectCardProps {
  title: string;
  /** year or range, mono, right-aligned to the title */
  year?: string;
  summary?: string;
  /** tech chips, lowercase */
  stack?: string[];
  /** monochrome image path */
  image?: string;
  href?: string;
  style?: React.CSSProperties;
}
export declare function ProjectCard(props: ProjectCardProps): JSX.Element;
