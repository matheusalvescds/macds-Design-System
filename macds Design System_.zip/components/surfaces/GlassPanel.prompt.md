Dark glass container — blurred, desaturated backdrop with a lit top edge.

```jsx
<GlassPanel strong padding="var(--sp-7)">…</GlassPanel>
```

`strong` is the text-safe version (the zona de silêncio in panel form). Never gets a diffuse drop shadow; depth comes from `--depth-drop` and the light edge.
