export interface GlassPanelProps {
  children?: React.ReactNode;
  radius?: string;
  padding?: string;
  /** heavier blur + opaque surface — use when text sits over agitated imagery */
  strong?: boolean;
  style?: React.CSSProperties;
}
export declare function GlassPanel(props: GlassPanelProps): JSX.Element;
